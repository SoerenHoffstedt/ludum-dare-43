﻿using System;
using Microsoft.Xna.Framework;

namespace Barely.Interface {

    public class Window : Panel {

        public static readonly int titleBarOffset = 50;
        public TitleBar titleBar;
        private InterfaceManager ifManager;
        private object p;
        private Point pos;
        private bool v1;
        private bool v2;

        public Window(InterfaceManager ifManager, string title, Point pos, Point size, bool addBackButton = true)
            : base(true, ifManager, pos, size, ifManager.firstPanel, null) {

            Action clickBack = ifManager.BackToLastWindow;            

            titleBar = new TitleBar(ifManager, Colors.orange, title, this, false);
            if(addBackButton)
                titleBar.AddChild(new Button(false, ifManager, new Point(titleBar.size.X - 70, 5),
                    new Point(30, 30), ifManager.backSprites, null, clickBack));

            AddChild(titleBar);
            
            OnClose += (obj) => {
                if(obj.isOpen)
                {
                    ifManager.CloseWindow(this);
                }
            };

            OnOpen += (obj) => {
                if(!obj.isOpen)
                {
                    ifManager.OpenWindow(this);
                }
            };

            this.Close();
        }

    }  

}
