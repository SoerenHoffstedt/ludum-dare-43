﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface
{
    public class Tooltip : Panel
    {
        InterfaceManager ifManager;
        SpriteFont font;
        UIObject tooltipFor;
        TextLabel textLabel;
        public Tooltip(InterfaceManager ifManager) 
                : base(true, ifManager, new Point(100, 100), new Point(200, 100), ifManager.tooltipPanel, null)
        {
            this.ifManager = ifManager;
            font = ifManager.SmallFont;
            textLabel = new TextLabel(false, ifManager, FontSize.Small, new Point(6, 6), new Point(200, 100), "tooltip", Color.White, yOverflow: VertOverflow.Overflow);
            interactable = false;


            AddChild(textLabel);

            isOpen = false;
        }

        public override void Update(double deltaTime)
        {
            base.Update(deltaTime);

            if(isOpen || isOpening)
            {
                SetPosition();
            }

        }

        void SetPosition()
        {
            Position = Input.GetMousePosition() + new Point(10, -size.Y);

            if (X < 0)
                X += 20;
            if (Y < 0)
                Y += 45;
            if (X + size.X >= ifManager.GetResolution.X)
            {
                X = X - size.X - 15;
                Y -= 10;
            }
            if (Y + size.Y >= ifManager.GetResolution.Y)
                Y = Y - size.Y;
        }

        public void Open(UIObject tooltipFor)
        {
            this.tooltipFor = tooltipFor;
            string txt = Texts.Get(tooltipFor.tooltipID);
            txt = TextLabel.WrapText(font, txt, new Point(size.X - 12, 500));
            Vector2 s = font.MeasureString(txt);
            textLabel.size.Y = (int)s.Y;
            this.size.Y = 6 + 6 + (int)s.Y;
            textLabel.UpdateText(txt);
            SetPosition();
            Open();
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            base.Render(spriteBatch);

        }
    }
    
}
