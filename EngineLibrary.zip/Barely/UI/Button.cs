﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;
using System;
using System.Diagnostics;

namespace Barely.Interface {

    public static class SpriteExtensions {
        public static Sprite[] CopyInstances(this Sprite[] sprites)
        {
            Sprite[] retSprites = new Sprite[sprites.Length];
            for(int i = 0; i < sprites.Length; i++)
            {
                retSprites[i] = sprites[i].CopyInstance();
            }
            return retSprites;
        }
    }

    public class Button : UIObject 
{        
        public int spriteIndex = 0;
        public Color[] colors = { Color.White, Colors.veryLightGray, Colors.lightGray, Colors.gray};

        //For fading the colors
        protected int R0 { get { return colors[0].R; } set { colors[0].R = (byte)value; } }
        protected int R1 { get { return colors[1].R; } set { colors[1].R = (byte)value; } }
        protected int G0 { get { return colors[0].G; } set { colors[0].G = (byte)value; } }
        protected int G1 { get { return colors[1].G; } set { colors[1].G = (byte)value; } }
        protected int B0 { get { return colors[0].B; } set { colors[0].B = (byte)value; } }
        protected int B1 { get { return colors[1].B; } set { colors[1].B = (byte)value; } }
        protected int A0 { get { return colors[0].A; } set { colors[0].A = (byte)value; } }
        protected int A1 { get { return colors[1].A; } set { colors[1].A = (byte)value; } }

        public Action OnMouseUp;
        public Action OnMouseDown;
        public Action OnMouseOver;

        public bool hasWorldPosition;
        public Point worldPosition = Point.Zero;

        public Group<Button> group = null;

        public bool isActive = true;

        private TextLabel caption;

        public Button(bool isFirstLevelObject, InterfaceManager ifManager, Point position, Point size)
                    : base(isFirstLevelObject, ifManager, true, position, size, ifManager.buttonSprite)           
        {            
            SetColorInterpolation();
            if(isFirstLevelObject)
                ifManager.RegisterButton(this);
        }

        public Button(bool isFirstLevelObject, InterfaceManager ifManager, Point position, Point size, Sprite sprite)
                    : base(isFirstLevelObject, ifManager, true, position, size, sprite)
        {
            SetColorInterpolation();
            if (isFirstLevelObject)
                ifManager.RegisterButton(this);          
        }

        public Button(bool isFirstLevelObject, InterfaceManager ifManager, Point position, Point size, Sprite sprite, string tooltipID)
                    : base(isFirstLevelObject, ifManager, true, position, size, sprite)
        {
            SetColorInterpolation();
            if (isFirstLevelObject)
                ifManager.RegisterButton(this);

            this.tooltipID = tooltipID;
        }

        public Button(bool isFirstLevelObject, InterfaceManager ifManager, Point position, Point size, string captionTextId, Color textColor, FontSize fontSize = FontSize.Small)
                    : base(isFirstLevelObject, ifManager, true, position, size, ifManager.buttonSprite)
        {            
            AddTextCaption(ifManager, captionTextId, textColor, fontSize);

            SetColorInterpolation();

            if(isFirstLevelObject)
                ifManager.RegisterButton(this);           
        }

        public Button(bool isFirstLevelObject, InterfaceManager ifManager, Point position, Point size, Sprite sprite, 
            UIObject[] childObjects, Action OnMouseUp, Action OnMouseDown = null, Action OnMouseOver = null, string captionTextId = null) 
            : base(isFirstLevelObject, ifManager, true, position, size, sprite) {

            
            
            if(this.sprite == null)
                this.sprite = ifManager.buttonSprite.CopyInstance(); 
            
            this.childObjects = childObjects;
            this.OnMouseUp = OnMouseUp;
            this.OnMouseDown = OnMouseDown;
            this.OnMouseOver = OnMouseOver;

            SetColorInterpolation();

            if(isFirstLevelObject)
                ifManager.RegisterButton(this);

        }

        public void SetMouseOverColors(Color[] colors)
        {
            Debug.Assert(colors.Length == 4);
            this.colors = colors;
            SetColorInterpolation();
        }

        void SetColorInterpolation() {
            Color n = colors[0];
            Color h = colors[1];

            OnMouseEnter += (obj) => {
                colors[1] = n;
                InterfaceManager.tweener.Tween(this, new { R1 = h.R, G1 = h.G, B1 = h.B, A1 = h.A }, .088f);
            };
            OnMouseExit += (obj) => {
                colors[0] = h;
                InterfaceManager.tweener.Tween(this, new { R0 = n.R, G0 = n.G, B0 = n.B, A0 = n.A }, .088f);
            };
        }

        public void UpdateCaptionText(string textId)
        {
            if(caption != null)            
                caption.UpdateText(textId);                            
        }



        public void AddTextCaption(InterfaceManager ifManager, string text, Color color, FontSize fontSize = FontSize.Normal) {         
            caption = new TextLabel(false, ifManager, fontSize, new Point(0, 0), new Point(size.X, size.Y), text, color, AllignmentX.Middle, AllignmentY.Middle, xOverflow: HorOverflow.Wrap);
            AddChild(caption);
        }

        public override void Update(double deltaTime) {
            base.Update(deltaTime);
            if(hasWorldPosition)
            {
                Position = Camera.main.ToScreen(worldPosition);
            }
        }

        public override void MouseEnter() {
            base.MouseEnter();
            if(isActive)
            {
                Sounds.Play("buttonMouseEnter");
                spriteIndex = (int)SpriteState.MouseOver;
            }

            if (!isActive)
                spriteIndex = (int)SpriteState.Inactive;

        }

        public override void MouseExit() {
            base.MouseExit();

            if(isActive && !isMouseDown)
                spriteIndex = (int)SpriteState.Normal;
            
        }

        public override void LeftMouseDown() {
            if(isActive)
                spriteIndex = (int)SpriteState.MouseDown;
        }

        public override void LeftMouseClick(Point clickPos) {
            if(!isActive)
                return;

            if(group != null)            
                group.Ping(this);

            if (isMouseOver)
                spriteIndex = (int)SpriteState.MouseOver;
            else
                spriteIndex = (int)SpriteState.Normal;

            Sounds.Play("click");
            OnMouseUp?.Invoke();

        }

        public override void RightMouseClick() {
            base.RightMouseClick();
            Sounds.Play("click");
        }

        public void DeActivate() {
            isActive = !isActive;

            if(isActive)
            {
                if(isMouseDown)
                    spriteIndex = (int)SpriteState.MouseDown;
                else if(isMouseOver)
                    spriteIndex = (int)SpriteState.MouseOver;
                else
                    spriteIndex = (int)SpriteState.Normal;

                if (caption != null)
                    caption.color = colors[spriteIndex];

            } else {
                spriteIndex = (int)SpriteState.Inactive;
                if(caption != null)                
                    caption.color = colors[spriteIndex];                
            }
        }

        public override void Render(SpriteBatch spriteBatch) {
            if(!isOpen && !isOpening && !isClosing)
                return;

            sprite?.Render(spriteBatch, new Rectangle(Position,size), colors[spriteIndex]);

            if(childObjects == null)
                return;

            for(int i = 0; i < childObjects.Length; i++)
            {
                childObjects[i].RenderAsChild(spriteBatch, this.Position);
            }
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            if(!isOpen && !isOpening && !isClosing)
                return;

            sprite?.Render(spriteBatch, new Rectangle(Position + parentPos, size), colors[spriteIndex]);

            if(childObjects == null)
                return;

            for(int i = 0; i < childObjects.Length; i++)
            {
                childObjects[i].RenderAsChild(spriteBatch, this.Position + parentPos);
            }
        }


    }
}
