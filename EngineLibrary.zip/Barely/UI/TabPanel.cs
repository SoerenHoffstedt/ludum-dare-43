﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface
{
    public enum Direction { Horizontal, Vertical }

    public class TabPanel : Panel
    {
        private int standardPanelId = 0;
        private int openPanelId = 0;    
        private Panel[] panels;
        private Button[] buttons;

        private Direction direction;
        private Point buttonSize;
        private InterfaceManager ifManager;
        private string[] tabNames;
        private Sprite normalSprite;
        private Sprite selectedSprite;

        public TabPanel(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, 
                        string[] tabNames, Panel[] panels, Point tabButtonSize,
                        Sprite normalSprites, Sprite selectedSprites, 
                        Direction dir = Direction.Horizontal, int standardPanelId = 0)
                 : base(isFirstLevelObject, ifManager, pos, size, null, null)
        
        {
            direction = dir;
            this.openPanelId = this.standardPanelId = standardPanelId;
            this.panels = panels;
            this.ifManager = ifManager;
            buttonSize = tabButtonSize;
            this.tabNames = tabNames;
            this.normalSprite = normalSprites;
            this.selectedSprite = selectedSprites;

            OnOpen += (obj) => openPanelId = standardPanelId;
            CreateTabButtons();
            AddChild(panels);
        }

        public TabPanel(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size,
                        string[] tabNames, Panel[] panels, Point tabButtonSize,                        
                        Direction dir = Direction.Horizontal, int standardPanelId = 0)
                 : this(isFirstLevelObject, ifManager, pos, size, tabNames, panels, tabButtonSize,
                        ifManager.normalTabButton, ifManager.selectedTabButton, dir, standardPanelId)

        {

        }

        void CreateTabButtons() {
            buttons = new Button[panels.Length];
            for(int i = 0; i < panels.Length; i++) {
                int index = i;               
                buttons[index] = new Button(false, ifManager, new Point(5 + i * buttonSize.X, 2), buttonSize, normalSprite, null, null);
                buttons[index].AddTextCaption(ifManager, tabNames[index], Color.White, FontSize.Small);
                buttons[index].OnMouseUp = () => { ChangeSelectedTab(index); };
                panels[index].isOpen = false;
            }
            buttons[openPanelId].sprite = selectedSprite;
            panels[openPanelId].isOpen = true;
            AddChild(buttons);
        }

        void ChangeSelectedTab(int newTab) {

            buttons[openPanelId].sprite = normalSprite;
            buttons[newTab].sprite = selectedSprite;

            panels[openPanelId].isOpen = false;
            panels[newTab].isOpen = true;

            openPanelId = newTab;
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            if (!isOpen && !isOpening)
                return;

            sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size));

            for(int i = 0; i < childObjects.Length; i++) {
                childObjects[i]?.RenderAsChild(spriteBatch, parentPos + Position);
            }
        }
    }
}
