﻿using System;
using System.Collections.Generic;

namespace Barely.Interface {
    public interface IListable<T> where T : IListable<T> {

        object[] ListElementsToDisplay();

        string[] DisplayingListElementsNames();

        /// <summary>
        /// bool indicates if it shall be sorted backwards
        /// </summary>
        /// <returns></returns>
        Action<List<SortableListEntry<T>>, bool>[] GetListSortingActions();  
        
        Action<object[]> GetElementUpdateDelegate();

        float[] entryWidth();    
    }
}
