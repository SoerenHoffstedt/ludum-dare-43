﻿using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace Barely.Interface {

    public enum AllignmentX { Left, Middle, Right }
    public enum AllignmentY { Top, Middle, Right }
    public enum HorOverflow { Wrap, Overflow, Truncate }
    public enum VertOverflow { Overflow, Truncate }

    public class TextLabel : UIObject {

        HorOverflow xOverflow;
        VertOverflow yOverflow;
        AllignmentX allignX;
        AllignmentY allignY;
        Vector2 allignOffset;

        public SpriteFont font;
        public string pureText;
        public string displayingText;
        public Color color;

        public int R { get { return color.R; } set { color.R = (byte)value; } }
        public int G { get { return color.G; } set { color.G = (byte)value; } }
        public int B { get { return color.B; } set { color.B = (byte)value; } }
        public int A { get { return color.A; } set { color.A = (byte)value; } }

        private Func<string> updateText;
        private bool updateTextPerFrame = false;
        private string translationId;



        public TextLabel(bool isFirstLevelObject, InterfaceManager ifManager, FontSize fontSize, Point pos, Point size, string textId, 
            Color color, AllignmentX allignX = AllignmentX.Left, AllignmentY allignY = AllignmentY.Top, 
            HorOverflow xOverflow = HorOverflow.Wrap, VertOverflow yOverflow = VertOverflow.Truncate, Func<string> updateText = null, bool updateTextPerFrame  = false)
            : base(isFirstLevelObject, ifManager, false, pos, size, null) {

            this.Position   = pos;
            this.size       = size;
            this.color      = color;
            this.updateTextPerFrame = updateTextPerFrame;
            this.font = ifManager.GetFont(fontSize);
            translationId = textId;
            this.updateText = updateText;
            if(updateText == null) {
                this.updateText = () => { return Texts.Get(translationId); };
                this.pureText = this.updateText();
            } else 
                this.pureText = Texts.Get(translationId);
            
            this.xOverflow  = xOverflow;
            this.yOverflow  = yOverflow;        
            this.allignX    = allignX;
            this.allignY    = allignY;
            CalcAllignOffset();
            ifManager.textLabels.Add(this);
        }

        public void SetUpdateTextFunction(Func<string> newUp) {
            this.updateText = newUp;
            updateTextPerFrame = newUp != null;
        }        

        public void UpdateText(string newText, bool getTranslation = true) {
            if (getTranslation)
                pureText = Texts.Get(newText);
            else
                pureText = newText;
            CalcAllignOffset();
        }

        public override void Update(double deltaTime) {
            base.Update(deltaTime);
            if(updateTextPerFrame && updateText != null)
            {
                ReloadText();
            }
        }

        public void ReloadText() {
            if (updateText != null)
            {
                pureText = updateText();
                CalcAllignOffset();
            }
        }

        void CalcAllignOffset() {

            
            if(xOverflow == HorOverflow.Wrap) {
                displayingText = UIObject.WrapText(font, pureText, size);
            } else if(xOverflow == HorOverflow.Truncate) {
                throw new NotImplementedException("Truncate for text label calcAllignOffset not implemented because i am an idiot.");
            } else {
                displayingText = pureText;
            }

            Vector2 stringSize = font.MeasureString(displayingText);
            
            switch(allignX)
            {
                case AllignmentX.Left:
                    allignOffset.X = 0;
                    break;
                case AllignmentX.Middle:
                    allignOffset.X = size.X / 2 - stringSize.X / 2;
                    break;
                case AllignmentX.Right:
                    allignOffset.X = size.X - stringSize.X - 5;
                    break;
                default:
                    break;
            }

            switch(allignY)
            {
                case AllignmentY.Top:
                    allignOffset.Y = 0;
                    break;
                case AllignmentY.Middle:
                    allignOffset.Y = size.Y / 2 - stringSize.Y / 2;
                    break;
                case AllignmentY.Right:
                    allignOffset.X = size.Y - stringSize.Y - 5;
                    break;
                default:
                    break;
            }            
            
        }

        public override void LeftMouseClick(Point clickPos)
        {
            base.LeftMouseClick(clickPos);
        }

        public override void Render(SpriteBatch spriteBatch) {
            if(!isOpen && !isOpening && !isClosing)
                return;

            spriteBatch.DrawString(font, displayingText, Position.ToVector2() + allignOffset, color);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            if(!isOpen && !isOpening && !isClosing)
                return;

            spriteBatch.DrawString(font, displayingText, Position.ToVector2() + parentPos.ToVector2() + allignOffset, color);
        }

       

    }
}
