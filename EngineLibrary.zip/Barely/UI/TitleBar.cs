﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;


namespace Barely.Interface {
    public class TitleBar : UIObject {

        private static int height = 40;

        public bool dragable;
        bool isDragging = false;
        Point dragPos;
        TextLabel headline;
        public Button closeButton;

        public UIObject parentObject;

        public TitleBar(InterfaceManager ifManager, Color color, 
            string titleText, UIObject parentObject, bool dragable) 
            : base(false, ifManager, true, new Point(5, 5), new Point(parentObject.size.X - 10, height), null) {

            childObjects = new UIObject[2];

            childObjects[0] = closeButton = new Button(false, ifManager, new Point(size.X - 35, 5), 
                new Point(32,32), ifManager.closeButtonSprite, null, parentObject.Close);

                        

            headline = new TextLabel(false, ifManager, FontSize.Big, 
                new Point(10, 0), new Point(parentObject.size.X - 45, height), titleText, color, allignY: AllignmentY.Middle);
            childObjects[1] = headline;

            this.parentObject = parentObject;
            this.dragable = dragable;

            sprite = ifManager.titleBarSprite;

        }

        public void ChangeTitle(string newTitle) {
            headline.UpdateText(newTitle);
        }

        public override void LeftMouseClick(Point clickPos) {

            if(isDragging)
            {
                isDragging = false;
            }

        }

        public override void MouseExit() {
            base.MouseExit();
            if(isDragging)
                isDragging = false;
        }

        public override void LeftMouseDown() {
            base.LeftMouseDown();
            if(dragable)
            {
                isDragging = true;
                dragPos = Input.GetMousePosition();
            }
        }

        public override void LeftMousePressed() {
            base.LeftMousePressed();

            if(dragable && isDragging)
            {
                Point newPos = Input.GetMousePosition();
                parentObject.Position -= dragPos - newPos;
                dragPos = newPos;
            }
        }

        public override void Render(SpriteBatch spriteBatch) {
            if(!isOpen)
                return;

            sprite.Render(spriteBatch, new Rectangle(Position, size));

            if(childObjects != null)
            {
                foreach(UIObject child in childObjects)
                {
                    child.RenderAsChild(spriteBatch, Position);
                }
            }
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            if(!isOpen)
                return;

            sprite?.Render(spriteBatch, new Rectangle(Position + parentPos, size ));
            if(childObjects != null)
            {
                foreach(UIObject child in childObjects)
                {
                    child.RenderAsChild(spriteBatch, parentPos + Position);
                }
            }

        }

    }
}
