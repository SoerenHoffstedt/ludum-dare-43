﻿using System;
using System.Collections.Generic;
using Barely.Util;
using Microsoft.Xna.Framework;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface
{
    public class SelectableList<T> : Panel
    {
        Sprite listSelectedBackground;
        T selected;
        T[] elements;
        ListElement<T>[] labels;
        Func<T, string> GetDescription;
        Color textColor;
        int entryHeight = 20;

        Action<T> OnElementChanged;
        InterfaceManager ifManager;
        Point scrollOffset;

        public SelectableList(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, T[] elements, Func<T, string> GetDescription, Color textColor, Action<T> OnElementChanged) 
             : base(isFirstLevelObject, ifManager, pos, size, ifManager.firstPanel, null)
        {
            listSelectedBackground = ifManager.listSelectedBackground;
            this.ifManager = ifManager;
            this.GetDescription = GetDescription;
            this.OnElementChanged = OnElementChanged;
            this.textColor = textColor;
            padding = new Point(5, 5);
            ChangeListData(elements);
        
        }

        public T GetSelectedElement() {
            return selected;
        }

        public void ChangeListData(T[] elements) {
            //Debug.Assert(elements.Length > 0);

            childObjects = null;

            scrollOffset = new Point(0, 0);

            this.elements = elements;
            if(elements != null && elements.Length > 0)
                ElementClicked(elements[0]);
            else
                ElementClicked(default(T));

            labels = new ListElement<T>[elements.Length];

            

            for(int i = 0; i < elements.Length; i++)
            {
                labels[i] = new ListElement<T>(elements[i], ElementClicked, ifManager, FontSize.Small,
                                          new Point(padding.X, padding.Y + i * entryHeight),
                                          new Point(size.X - 2 * padding.X, entryHeight),
                                          GetDescription(elements[i]), textColor, 
                                          allignX: AllignmentX.Middle, allignY: AllignmentY.Middle);
                
            }

            AddChild(labels);
        }        

        void ElementClicked(T element) {
            selected = element;
            if(selected != null)
                OnElementChanged?.Invoke(selected);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            sprite.Render(spriteBatch, new Rectangle(parentPos + Position, size));
            for(int i = 0; i < labels.Length; i++) {
                if(elements[i].Equals(selected))
                    listSelectedBackground.Render(spriteBatch, new Rectangle( parentPos + Position + new Point(padding.X, padding.Y + i * entryHeight), new Point(size.X - 2 * padding.X, entryHeight)), Color.Pink);
                labels[i].RenderAsChild(spriteBatch, parentPos + Position);
            }
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            this.RenderAsChild(spriteBatch, Point.Zero);
        }


        class ListElement<T> : TextLabel
        {
            Action<T> ClickCallback;
            T element;

            public ListElement(T element, Action<T> ClickCallback, InterfaceManager ifManager, FontSize fontSize, Point pos, Point size, string textId, Color color, AllignmentX allignX = AllignmentX.Left, AllignmentY allignY = AllignmentY.Top, HorOverflow xOverflow = HorOverflow.Wrap, VertOverflow yOverflow = VertOverflow.Truncate, Func<string> updateText = null, bool updateTextPerFrame = false) 
                        : base(false, ifManager, fontSize, pos, size, textId, color, allignX, allignY, xOverflow, yOverflow, updateText, updateTextPerFrame)
            {
                this.interactable = true;
                this.element = element;
                this.ClickCallback = ClickCallback;
            }

            public override void LeftMouseClick(Point mousePos)
            {                
                ClickCallback(element);
            }

        }
    }
}
