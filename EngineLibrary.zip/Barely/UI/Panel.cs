﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;

namespace Barely.Interface {

    public class Panel : UIObject {

        public Panel(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, Sprite sprite, UIObject[] childs) : 
            base(isFirstLevelObject, ifManager, true, pos, size, sprite) {

            childObjects = childs;
            if(isFirstLevelObject)
                ifManager.RegisterPanel(this);
        }


        public override void Render(SpriteBatch spriteBatch) {
            if(!isOpen && !isOpening && !isClosing)
                return;

            sprite?.Render(spriteBatch, new Rectangle(Position, size));
            if(childObjects != null)
            {
                for(int i = 0; i < childObjects.Length; i++)
                {
                    if(childObjects[i] != null) 
                        childObjects[i].RenderAsChild(spriteBatch, Position);
                }
            }
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            if(!isOpen && !isOpening && !isClosing)
                return;

            sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size));
            if(childObjects != null)
            {
                for(int i = 0; i < childObjects.Length; i++)
                {
                    childObjects[i].RenderAsChild(spriteBatch, Position + parentPos);
                }
            }
        }


        public override void LeftMouseClick(Point clickPos) {
        }

        public override void MouseEnter() {
            base.MouseEnter();
        }

        public override void MouseOver() {
            base.MouseOver();
        }

        public override void MouseExit() {
            base.MouseExit();
        }

        public override void RightMouseClick() {
            base.RightMouseClick();
        }


    }
}
