﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;

namespace Barely.Interface {
    public class Image : UIObject {

        public Color color;
        Sprite frameSprite;

        public Image(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, Sprite sprite, Sprite frameSprite = null) 
            : base(isFirstLevelObject, ifManager, true, pos, size, sprite) {
            color = Color.White;
        }

        public void UpdateSprite(Sprite newSprite) {
            sprite = newSprite;
        }


        public override void Render(SpriteBatch spriteBatch) {
            if (!isOpen && !isOpening)
                return;
            frameSprite?.Render(spriteBatch, new Rectangle(Position, size));
            sprite?.Render(spriteBatch, new Rectangle(Position, size));
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            if (!isOpen && !isOpening)
                return;
            frameSprite?.Render(spriteBatch, new Rectangle(Position + parentPos, size));            
            sprite?.Render(spriteBatch, new Rectangle(Position + parentPos, size), color);
        }

    }
}
