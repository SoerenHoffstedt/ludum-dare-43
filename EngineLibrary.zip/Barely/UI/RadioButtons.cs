﻿using Barely.Interface;
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;

namespace Barely.Interface
{
    public class RadioButtons : UIObject
    {
        
        public enum RadioButtonsLayout { Horizontal, Vertical }

        int numOfBoxes;
        int currentlySelected;

        RadioButton[] buttons;
        Action<int> callback;

        public RadioButtons(InterfaceManager ifManager, Point pos, RadioButtonsLayout layout, int maxPerLayoutDirection, 
                     Sprite bgSprite, int numOfBoxes, string[] descriptionIds, Action<int> callback, 
                     int startSelected, Point radioButtonSize, Point radioButtonPadding) 
                     : base(false, ifManager, true, pos, Point.Zero, bgSprite)
        {
            
            System.Diagnostics.Debug.Assert(numOfBoxes == descriptionIds.Length && startSelected < numOfBoxes);

            this.numOfBoxes = numOfBoxes;
            currentlySelected = startSelected;
            this.callback = callback;

            Point p = radioButtonPadding;
            buttons = new RadioButton[numOfBoxes]; 
            for(int i = 0; i < numOfBoxes; i++) {
                int index = i;

                if(index % maxPerLayoutDirection == 0) {
                    p = radioButtonPadding;
                    if(layout == RadioButtonsLayout.Horizontal) {                        
                        p.Y += radioButtonSize.Y + radioButtonPadding.Y;
                    } else if(layout == RadioButtonsLayout.Vertical) {
                        p.X += radioButtonSize.X + radioButtonPadding.X;
                    }
                }                    

                buttons[index] = new RadioButton(ifManager, p, radioButtonSize, false, descriptionIds[index], index, ButtonClick);
                
                if(layout == RadioButtonsLayout.Horizontal) {
                    p.X += radioButtonPadding.X + radioButtonSize.X;
                } else if(layout == RadioButtonsLayout.Vertical) {
                    p.Y += radioButtonPadding.Y + radioButtonSize.Y;
                }

            }

            if (layout == RadioButtonsLayout.Horizontal)
            {
                size = new Point(p.X + radioButtonSize.X, radioButtonSize.Y * 2);
            }
            else if (layout == RadioButtonsLayout.Vertical)
            {
                size = new Point(radioButtonSize.X * 2, p.Y + radioButtonSize.Y);
            }

            ButtonClick(buttons[startSelected]);    

            AddChild(buttons);
        }

        void ButtonClick(RadioButton button) {
            buttons[currentlySelected].isSelected = false;
            
            int index = button.myIndex;
            currentlySelected = index;
            callback(index);
            buttons[index].isSelected = true;
        }

        
        public override void Render(SpriteBatch spriteBatch)
        {
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size));
            
            for(int i = 0; i < childObjects.Length; i++) {
                childObjects[i].RenderAsChild(spriteBatch, parentPos + Position);
            }
        }
    }

    class RadioButton : Button
    {

        public bool isSelected = false;
        public int myIndex;
        private Action<RadioButton> callback;
        Sprite isSelectedGraphic;
        TextLabel caption;

        public RadioButton(InterfaceManager ifManager, Point position, Point size, 
                            bool startVal, string textID, int myIndex, Action<RadioButton> callback) 
                        : base(false, ifManager, position, size, ifManager.radioButton, null, null, 
                            null, null)
        {
            this.myIndex = myIndex;
            this.callback = callback;
            sprite = ifManager.radioButton;
            isSelectedGraphic = ifManager.radioButtonSelectedGraphic;
            caption = new TextLabel(false, ifManager, FontSize.Normal, position + new Point(size.X + 5, 0), new Point(100, size.Y), textID, Colors.orange, allignY: AllignmentY.Middle);
        }

        public override void LeftMouseClick(Point clickPos)
        {
            base.LeftMouseClick(clickPos);
            callback(this);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            base.RenderAsChild(spriteBatch, parentPos);
            caption.RenderAsChild(spriteBatch, parentPos);
            if(isSelected)
                isSelectedGraphic.Render(spriteBatch, parentPos + Position);
        }

    }
}
