﻿using System;
using Microsoft.Xna.Framework;
using Barely.Util;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface {
    public class Dropdown : UIObject {

        bool isExpanded;

        Color mainColor = Color.White;

        Sprite leftMain;
        Sprite rightMain;
        int h;
        int leftW;
        int rightW;

        Sprite arrow;
        Point arrowOffset;
        Action closeDropdown;
        Action openDropdown;

        int entryCount;
        UIObject[] childs;
        TextLabel currentlySelectedTextLabel;

        public Dropdown(InterfaceManager ifManager, Point pos, string[] entries, Action[] entryCallbacks, UIObject parent, int selected = 0)
            : base(false, ifManager, true, pos, new Point(180,40), null) {

            Debug.Assert(entries.Length == entryCallbacks.Length, "Oh, fuck the dropdown has different sizes for entries and entryCallbacks");
            entryCount = entries.Length;

            leftMain = ifManager.dropdownLeftMain;
            rightMain = ifManager.dropdownRightMain;

            h = 40;
            rightW = 40;
            leftW = size.X - rightW;

            arrow = ifManager.dropdownArrow;
            arrowOffset = new Point(leftW + (rightW - arrow.spriteRect.Width) / 2, (h - arrow.spriteRect.Height) / 2);

            int y = (int)(h - ifManager.SmallFont.MeasureString("TEstK").Y) / 2;
            currentlySelectedTextLabel = new TextLabel(false, ifManager, FontSize.Small, new Point(10, y), new Point(leftW - 12, h), entries[selected], Color.White);
            AddChild(currentlySelectedTextLabel);

            childs = new UIObject[entries.Length]; //+ 1];

            for(int i = 0; i < entries.Length; i++)
            {
                int index = i;
                Button button = new Button(false, ifManager, new Point(pos.X, pos.Y + (i+1)*(size.Y-1)), size, ifManager.dropdownEntry, null, 
                    entryCallbacks[i] += () => { closeDropdown(); currentlySelectedTextLabel.UpdateText(entries[index]); });

                button.AddTextCaption(ifManager, entries[i], Color.White, FontSize.Small);
                childs[i] = button;
                closeDropdown += () => button.Close();
                openDropdown += () => button.Open();
                childs[i].Close();
            }
            parent.AddChild(childs);

            isExpanded = false;

            OnMouseEnter += (obj) => mainColor = Colors.veryLightGray;
            OnMouseExit += (obj) => mainColor = Color.White;

            closeDropdown += () => isExpanded = false;
            openDropdown += () => isExpanded = true;

            childs[selected].LeftMouseClick(Point.Zero);

        }

        public override void LeftMouseClick(Point clickPos) {
            Debug.WriteLine(clickPos);
                    
           if(isExpanded) {
                closeDropdown?.Invoke();
            } else {
                openDropdown?.Invoke();
            }
        }

        void Expand() {

        }

        void Collapse() {

        }

        public void SetValue(uint index)
        {
            Debug.Assert(index < entryCount);
            childs[index].LeftMouseClick(Point.Zero);
        }


        public override void Render(SpriteBatch spriteBatch) {
            
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            leftMain?.Render(spriteBatch, new Rectangle(parentPos + Position, new Point(leftW,h)), mainColor);
            rightMain?.Render(spriteBatch, new Rectangle(parentPos + Position + new Point(leftW,0), new Point(rightW, h)), mainColor);
            arrow?.Render(spriteBatch, parentPos + Position + arrowOffset, mainColor);

            for(int i = 0; i < childObjects.Length; i++) {
                childObjects[i].RenderAsChild(spriteBatch, parentPos + Position);
            }

        }

    }
}
