﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Diagnostics;

namespace Barely.Interface
{
    public class ScrollText : UIObject
    {

        private string pureText;
        private string displayText;
        private SpriteFont font;
        private int textMargin;
        private int scrollBarWidth;
        private Point marginOffset;
        private Color color;
        private GraphicsDevice GraphicsDevice;

        private Point textSize;
        private float maxOffset;
        private Vector2 scrollOffset;

        public Func<string> updateTextDelegate;

        private ScrollBarBackground sbBackground;
        private ScrollBarHandle sbHandle;

        public ScrollText(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, 
                            int textMargin, Sprite bgSprite, string text, FontSize fontSize, Color color, Func<string> updateTextDelegate = null, int scrollBarWidth = 20) 
                            : base(isFirstLevelObject, ifManager, true, pos, size, bgSprite)
        {
            this.textMargin = textMargin;
            this.scrollBarWidth = scrollBarWidth;
            this.GraphicsDevice = ifManager.GraphicsDevice;
            this.color = color;
            this.updateTextDelegate = updateTextDelegate;

            marginOffset = new Point(textMargin, textMargin);

            font = ifManager.GetFont(fontSize);
            pureText = text;
            textSize = new Point(size.X - 3 * textMargin - scrollBarWidth, size.Y - 2 * textMargin);
                       
            sbBackground = new ScrollBarBackground(ifManager, new Point(size.X - textMargin - scrollBarWidth, textMargin), new Point(scrollBarWidth,  textSize.Y), this);
            sbHandle = new ScrollBarHandle(ifManager, new Point(size.X - textMargin - scrollBarWidth + 4, textMargin + 4), new Point(scrollBarWidth - 8, 100), sbBackground, this);

            childObjects = new UIObject[] { sbBackground, sbHandle };
            UpdateText(text);    
        }

        public override void Update(double deltaTime)
        {
            if(isOpen && updateTextDelegate != null)
                UpdateText(updateTextDelegate());

            base.Update(deltaTime);
        }

        public void UpdateText(string newText) {
            pureText = newText;
            displayText = TextLabel.WrapText(font, pureText, new Point(textSize.X, 5000));

            float dispTextHeight = font.MeasureString(displayText).Y;

            maxOffset = (float)dispTextHeight - textSize.Y;           

            int handleHeight;
            if(maxOffset < 0)
                handleHeight = textSize.Y - 8;
            else
                handleHeight = (int)((float)(textSize.Y - 8) * ((float)size.Y / ((float)size.Y + maxOffset)));

            maxOffset *= -1;
            scrollOffset = new Vector2(0, 0);

            sbHandle.Reset(new Point(scrollBarWidth - 8, handleHeight));
        }


        public override void Render(SpriteBatch spriteBatch)
        {
            if(!isOpen)
                return;

            sprite?.Render(spriteBatch, new Rectangle(Position, size));

            Rectangle old = GraphicsDevice.ScissorRectangle;

            GraphicsDevice.ScissorRectangle = new Rectangle(Position + marginOffset, textSize);

            spriteBatch.DrawString(font, displayText, Position.ToVector2() + marginOffset.ToVector2() + scrollOffset, color);

            GraphicsDevice.ScissorRectangle = old;

            sbBackground?.RenderAsChild(spriteBatch, this.Position);
            sbHandle?.RenderAsChild(spriteBatch, this.Position);
        }


        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            if(!isOpen)
                return;

            sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size));

            Rectangle old = GraphicsDevice.ScissorRectangle;

            GraphicsDevice.ScissorRectangle = new Rectangle(parentPos + Position + marginOffset, textSize);

            spriteBatch.DrawString(font, displayText, parentPos.ToVector2() + Position.ToVector2() + marginOffset.ToVector2() + scrollOffset, color);
            
            GraphicsDevice.ScissorRectangle = old;

            sbBackground?.RenderAsChild(spriteBatch, this.Position + parentPos);
            sbHandle?.RenderAsChild(spriteBatch, this.Position + parentPos);
        }

        public override void ScrollWheelUp()
        {
            scrollOffset.Y += Input.GetMouseWheelDelta();

            if (scrollOffset.Y > 0)
                scrollOffset.Y = 0;
            if (scrollOffset.Y < maxOffset)
                scrollOffset.Y = maxOffset;

            sbHandle.SetHandlePosition(scrollOffset.Y / maxOffset);
        }

        public override void ScrollWheelDown()
        {
            ScrollWheelUp();
        }

        public void SetScrollOffset(float factor) {
            scrollOffset.Y = factor * maxOffset;
        }




        private class ScrollBarHandle : UIObject
        {

            private int minHeight = 10;

            private ScrollBarBackground sbBackground;
            private ScrollText parent;

            private Color currColor;
            private Color mouseOverColor;
            private Color normalColor;
            private Color mouseDownColor;

            
            int topPosition { get { return sbBackground.Position.Y + 4; } }
            int bottomPosition { get { return topPosition + sbBackground.size.Y - 8 - size.Y; } }

            private bool dragging = false;
            private int mouseDownOffset;

            public ScrollBarHandle(InterfaceManager ifManager, Point pos, Point size, ScrollBarBackground sbBackground, ScrollText parent) 
                            : base(false, ifManager, true, pos, size, ifManager.scrollBarHandle)
            {
                this.sbBackground = sbBackground;
                this.parent = parent;

                if(size.Y < minHeight)
                    size.Y = minHeight;

                normalColor = Color.White;
                mouseOverColor = Color.Gray;
                currColor = normalColor;

                ifManager.RegisterUIObjectToHandleInputAsFirstLevel(this);

            }

            public void Reset(Point newSize) {
                this.size = newSize;
                if(size.Y < minHeight)
                    size.Y = minHeight;

                this.Y = topPosition;
            }

            public void SetHandlePosition(float factor) {
                this.Y =(int)((bottomPosition - topPosition) * factor) + topPosition;
            }

            public override void Update(double deltaTime)
            {

                if(dragging) {
                    this.Y = Input.GetMousePosition().Y - mouseDownOffset - parentPos.Y - 4;

                    if(this.Y < topPosition)
                        this.Y = topPosition;
                    if(this.Y > bottomPosition)
                        this.Y = bottomPosition;

                    parent.SetScrollOffset((float)(this.Y - topPosition) / (float)(bottomPosition - topPosition));
                               
                }

                base.Update(deltaTime);
            }

            public override void LeftMouseDown()
            {
                base.LeftMouseDown();
                dragging = true;
                mouseDownOffset = Input.GetMousePosition().Y - parentPos.Y - Position.Y - 4;
            }

            public override void LeftMouseClick(Point clickPos)
            {
                base.LeftMouseClick(clickPos);
                dragging = false;
            }

            public override void MouseEnter()
            {
                base.MouseEnter();
                currColor = mouseOverColor;
            }

            public override void MouseExit()
            {
                base.MouseExit();
                currColor = normalColor;
            }

            public override void ScrollWheelDown()
            {
                parent.ScrollWheelDown();
            }

            public override void ScrollWheelUp()
            {
                parent.ScrollWheelUp();
            }

            public override void Render(SpriteBatch spriteBatch)
            {
                throw new NotImplementedException();
            }

            public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
            {
                sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size), currColor);
            }
        }


        private class ScrollBarBackground : UIObject
        {
            private ScrollText parent;
            private Color currColor;
            private Color mouseOverColor;
            private Color normalColor;

            public ScrollBarBackground(InterfaceManager ifManager, Point pos, Point size, ScrollText parent) 
                                : base(false, ifManager, true, pos, size, ifManager.scrollBarBackground)
            {
                normalColor = currColor = Color.White;
                mouseOverColor = Color.Gray;
                this.parent = parent;
            }

            public override void MouseEnter()
            {
                base.MouseEnter();

            }

            public override void MouseExit()
            {
                base.MouseExit();

            }

            public override void ScrollWheelDown()
            {
                parent.ScrollWheelUp();
            }

            public override void ScrollWheelUp()
            {
                parent.ScrollWheelUp();
            }

            public override void Render(SpriteBatch spriteBatch)
            {
                throw new NotImplementedException();
            }

            public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
            {
                sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size), currColor);
            }
        }

    }
}
