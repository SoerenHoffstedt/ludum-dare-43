﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface
{
    public class LineSeperator : UIObject
    {
        private Vector2 start, end;
        private Color color;
        private int thickness;

        public LineSeperator(InterfaceManager ifManager, Point startPoint, Point endPoint, Color color, int thickness) 
                      : base(false, ifManager, false, startPoint, Point.Zero, null)
        {
            start = startPoint.ToVector2();
            end = endPoint.ToVector2();
            this.color = color;
            this.thickness = thickness;
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            Vector2 parentVec = parentPos.ToVector2();
            spriteBatch.DrawLine(start + parentVec, end + parentVec, color, thickness);
        }
    }
}
