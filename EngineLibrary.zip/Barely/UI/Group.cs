﻿using System;

namespace Barely.Interface {
    public class Group<T> where T : UIObject {

        T[] groupObjects;
        T currentSelected;
        Action<T, bool> onSelect;
        Action<T, bool> onUnselect;


        public Group(T[] groupObjects, Action<T, bool> onSelect, Action<T, bool> onUnselect) {
            this.groupObjects = groupObjects;
            currentSelected = null;
            this.onSelect = onSelect;
            this.onUnselect = onUnselect;
        }

 
        public void Ping(T toPing) {
            if(currentSelected == null)
            {
                if(onSelect != null)
                    onSelect(toPing, true);

                currentSelected = toPing;
            }
            else if(toPing == currentSelected)
            {
                if(onUnselect != null)
                    onUnselect(toPing, true);
                currentSelected = null;
            } else
            {
                if(onUnselect != null)
                    onUnselect(currentSelected, false);
                currentSelected = toPing;
                if(onSelect != null)
                    onSelect(toPing, true);
            }
        }

    }
}
