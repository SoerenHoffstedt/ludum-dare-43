﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.ProgGen
{
    public static class CellularAutomata
    {

        //
        public static bool[,] Generate(Point size, int smoothIterations, int blockingTilePercentage, bool openCave, int? randomSeed = null)
        {
            bool[,] values = new bool[size.X, size.Y];

            int openess = openCave ? 4 : 3;

            /*Map newMap = new Map(width, height, set);
            mainRoom = null;
            map = newMap.map;  //new Tile[width, height];
            rooms = new List<Room>();*/


            Random random = randomSeed == null ? new Random() : new Random(randomSeed.Value);

            for (int x = 0; x < size.X; x++)
            {
                for (int y = 0; y < size.Y; y++)
                {
                    //if (x == 0 || x == size.X - 1 || y == 0 || y == size.Y - 1)
                    //    values[x, y] = true;
                    //else
                        values[x, y] = random.Next(0, 100) < blockingTilePercentage;

                }
            }

            //Smoothing
            for (int i = 0; i < smoothIterations; i++)
            {
                for (int x = 0; x < size.X; x++)
                {
                    for (int y = 0; y < size.Y; y++)
                    {
                        int wallCount = 0;
                        for (int neighX = x - 1; neighX <= x + 1; neighX++)
                        {
                            for (int neighY = y - 1; neighY <= y + 1; neighY++)
                            {
                                if (IsInRange(neighX, neighY, size))
                                {
                                    if (neighX != x || neighY != y)
                                    {
                                        if (values[neighX, neighY])
                                            wallCount += 1;
                                    }
                                }
                                else
                                    wallCount++;
                            }
                        }

                        if (wallCount > 4)
                            values[x, y] = true; // new Tile(GetRandomTileType(set.blocking));
                        else if (wallCount < openess)
                            values[x, y] = false; //new Tile(GetRandomTileType(set.normals));

                    }
                }
            }


            return values;
        }           


        private static bool IsInRange(int x, int y, Point size)
        {
            return x >= 0 && x < size.X && y >= 0 && y < size.Y;
        }

    }
}
