﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

namespace Barely.Util {

    public class Sprite {

        private static Random random = new Random();

        public Rectangle spriteRect;
        public Point Size { get { return spriteRect.Size; } }
        public Color color;
        public Texture2D atlas;

        public Point drawOffset;
        public int drawOffsetX { get { return drawOffset.X; } set { drawOffset.X = value; } }
        public int drawOffsetY { get { return drawOffset.Y; } set { drawOffset.Y = value; } }

        public bool isAnimated;
        protected Animation animation;
        double timer;

        public int R { get { return color.R; } set { color.R = (byte)value; } }
        public int G { get { return color.G; } set { color.G = (byte)value; } }
        public int B { get { return color.B; } set { color.B = (byte)value; } }
        public int A { get { return color.A; } set { color.A = (byte)value; } }

        /// <summary>
        /// Constructor to create a sprite by giving the animation data directly. It will create the animation automatically.
        /// </summary>
        /// <param name="atlas"></param>
        /// <param name="rects"></param>
        /// <param name="lengths"></param>
        /// <param name="color"></param>
        /// <param name="drawOffsets"></param>
        /// <param name="colors"></param>
        public Sprite(Texture2D atlas, Rectangle[] rects, double[] lengths, Color color, Point[] drawOffsets = null, Color[] colors = null, bool randomStartOffset = true)
        {
            if (rects.Length != lengths.Length)
                throw new ArgumentException("Sprite: Same amount of Rectangles and lengths have to be submitted.");
            Animation anim = new Animation(rects.Length, lengths, rects, drawOffsets, colors);
            this.spriteRect = rects[0];
            this.color = color;
            this.atlas = atlas;
            this.drawOffset = drawOffsets == null ? Point.Zero : drawOffsets[0];
            SetAnimation(anim, randomStartOffset);
        }

        public Sprite(Texture2D atlas, Rectangle spriteRect, Color color, Animation animation = null, Point drawOffset = new Point(), bool randomStartOffset = true) {
            this.spriteRect     = spriteRect;
            this.color          = color;
            this.atlas          = atlas;
            this.drawOffset     = drawOffset;

            SetAnimation(animation, randomStartOffset);
        }

        public Sprite(Texture2D atlas, Color color, Animation animation, Point drawOffset = new Point())
            : this(atlas, animation.rects[0], color, animation, drawOffset) { }

        public Sprite(Texture2D atlas, Rectangle spriteRect)
            : this(atlas, spriteRect, Color.White, null, Point.Zero) { }


        public void SetAnimation(Animation animation, bool randomStartOffset = true)
        {
            this.animation = animation;
            isAnimated = animation != null;
            timer = 0.0;
            if (isAnimated)
            {

                animation.stdColor      = color;
                animation.stdDrawOffset = drawOffset;

                if (randomStartOffset)
                {
                    if (animation.length != null)
                        timer = animation.length[0] * random.NextDouble();
                    else
                        timer = animation.leng * random.NextDouble();
                }
                else
                    timer = 0.0;

                animation.SetFirstFrame(this);

                Animator.AddSprite(this);
            }
        }

        internal void Update(double deltaTime) {
            //update animation
            if(isAnimated) {

                timer += deltaTime * 1000;

                if(timer >= animation.LengthOfCurrentFrame())
                {
                    animation.GetNextFrame(this);
                    timer = 0;
                }
            }

        }

        public virtual void Render(SpriteBatch spriteBatch, Rectangle destination) {
            destination.Location += drawOffset;
            spriteBatch.Draw(atlas, destination, spriteRect, color);
        }

        public virtual void Render(SpriteBatch spriteBatch, Rectangle destination, Color col) {
            destination.Location += drawOffset;
            spriteBatch.Draw(atlas, destination, spriteRect, col);
        }

        public virtual void Render(SpriteBatch spriteBatch, Rectangle destination, SpriteEffects spriteEffect)
        {
            destination.Location += drawOffset;
            spriteBatch.Draw(atlas, destination, spriteRect, color, 0f, Vector2.Zero, spriteEffect, 0);
        }

        public virtual void Render(SpriteBatch spriteBatch, Rectangle destination, SpriteEffects spriteEffect, Color col)
        {
            destination.Location += drawOffset;
            spriteBatch.Draw(atlas, destination, spriteRect, col, 0f, Vector2.Zero, spriteEffect, 0);
        }

        public virtual void Render(SpriteBatch spriteBatch, Point destination) {            
            spriteBatch.Draw(atlas, new Rectangle(destination + drawOffset, spriteRect.Size), spriteRect, color);
        }

        public virtual void Render(SpriteBatch spriteBatch, Point destination, Color col) {            
            spriteBatch.Draw(atlas, new Rectangle(destination + drawOffset, spriteRect.Size), spriteRect, col);
        }

        public virtual void Render(SpriteBatch spriteBatch, Point destination, SpriteEffects spriteEffect)
        {
            spriteBatch.Draw(atlas, new Rectangle(destination + drawOffset, spriteRect.Size), spriteRect, color, 0f, Vector2.Zero, spriteEffect, 0);
        }

        public virtual void Render(SpriteBatch spriteBatch, Point destination, SpriteEffects spriteEffect, Color col)
        {            
            spriteBatch.Draw(atlas, new Rectangle(destination + drawOffset, spriteRect.Size), spriteRect, col, 0f, Vector2.Zero, spriteEffect, 0);
        }

        public virtual void Render(SpriteBatch spriteBatch, Point destination, float depth, Color color)
        {
            destination+= drawOffset;
            spriteBatch.Draw(atlas, new Rectangle(destination, spriteRect.Size), spriteRect, color, 0f, Vector2.Zero, SpriteEffects.None, depth);
        }

        public virtual void Render(SpriteBatch spriteBatch, Point destination, float depth)
        {
            Render(spriteBatch, destination, depth, color);
        }

        public virtual void Render(SpriteBatch spriteBatch, Rectangle destination, float depth, Color color)
        {
            destination.Location += drawOffset;            
            spriteBatch.Draw(atlas, destination, spriteRect, color, 0f, Vector2.Zero, SpriteEffects.None, depth);
        }

        public virtual void Render(SpriteBatch spriteBatch, Rectangle destination, float depth)
        {
            Render(spriteBatch, destination, depth, color);
        }

        public virtual Sprite CopyInstance() {
            return new Sprite(atlas, spriteRect, color, animation?.CopyInstance());
        }

        //TODO: Support for animated 9-slice sprites
        //TODO: Support for everything, like DrawOffset, Color, etc.
        public static Sprite Parse(System.Xml.XmlNode n, Microsoft.Xna.Framework.Content.ContentManager Content)
        {
            System.Xml.XmlNodeList frames = n.SelectNodes("frame");
            if (frames.Count > 0)
            {
                Rectangle[] rects = new Rectangle[frames.Count];
                double[] length   = new double[frames.Count];
                for(int i = 0; i < frames.Count; i++)
                {
                    var fNode = frames[i];
                    length[i] = double.Parse(fNode.Attributes["length"].Value);
                    int x = int.Parse(fNode.Attributes["x"].Value);
                    int y = int.Parse(fNode.Attributes["y"].Value);
                    int w = int.Parse(fNode.Attributes["w"].Value);
                    int h = int.Parse(fNode.Attributes["h"].Value);
                    rects[i] = new Rectangle(x, y, w, h);                    
                }
                Texture2D texture = Content.Load<Texture2D>(n.Attributes["texture"].Value);
                return new Sprite(texture, rects, length, Color.White);
            }
            else
            {
                int x = int.Parse(n.Attributes["x"].Value);
                int y = int.Parse(n.Attributes["y"].Value);
                int w = int.Parse(n.Attributes["w"].Value);
                int h = int.Parse(n.Attributes["h"].Value);
                Texture2D texture = Content.Load<Texture2D>(n.Attributes["texture"].Value);
                if (n.Attributes["up"] != null)
                {
                    int up = int.Parse(n.Attributes["up"].Value);
                    int down = int.Parse(n.Attributes["down"].Value);
                    int left = int.Parse(n.Attributes["left"].Value);
                    int right = int.Parse(n.Attributes["right"].Value);
                    return new Sprite9Slice(texture, new Rectangle(x, y, w, h), left, right, up, down);
                }
                else
                {                    
                    return new Sprite(texture, new Rectangle(x, y, w, h));
                }
            }
        }

    }
}
