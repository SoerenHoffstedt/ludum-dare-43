﻿using System;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using System.Xml;
using System.Collections.Generic;
using System.Diagnostics;

namespace Barely.Util
{
    public static class Sounds
    {
        static Dictionary<string, SoundEffect[]> sounds;

        static float volume = 1f;
        static float pitch = 0.0f;
        static float pan = 0.0f;
        static Random random;

        static string folder;

        public static void Initialize(ContentManager Content, XmlDocument xmlDoc) {
            
            sounds = new Dictionary<string, SoundEffect[]>();
            random = new Random();

            XmlNode node = xmlDoc.SelectSingleNode("sounds");

            SoundEffect.MasterVolume = 1f;

            if(node == null)
                return;

            folder = $"{node.Attributes["folder"].Value}/";

            foreach(XmlNode n in node.SelectNodes("s")) {
                if(n.Attributes["file"] == null) {
                    XmlNodeList list = n.SelectNodes("file");
                    SoundEffect[] effs = new SoundEffect[list.Count];

                    for(int i = 0; i < list.Count; i++) {
                        effs[i] = Content.Load<SoundEffect>($"{folder}{list[i].Attributes["file"].Value}");
                    }
                    sounds.Add(n.Attributes["id"].Value, effs);

                } else {
                    string name = n.Attributes["file"].Value;
                    string id = n.Attributes["id"].Value;
                    SoundEffect eff = Content.Load<SoundEffect>($"{folder}{name}");
                    sounds.Add(id, new SoundEffect[] { eff } );
                }
            }            

        }

        public static void Reset()
        {
            //TODO stop playing sounds
        }

        public static void Play(string id) {
            if(sounds.ContainsKey(id))
            {
                if(sounds[id].Length == 1)
                    sounds[id][0].Play(volume, pitch, pan);
                else
                    sounds[id][random.Next(sounds[id].Length)].Play(volume, pitch, pan);
            }
            else
            {
                Debug.WriteLine($"Soundeffect {id} is not known.");
            }
        }

    }
}
