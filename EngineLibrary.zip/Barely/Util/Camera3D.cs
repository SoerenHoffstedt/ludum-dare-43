﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;


namespace Barely.Util
{
    public class Camera3D
    {
        private Vector3 _position;
        private Vector3 _up = Vector3.UnitZ;
        private Vector3 _forward = Vector3.Up;
        private float _fieldOfView = (float)Math.PI / 4;

        public bool HasChanged = true;
        public bool HasMoved;

        private Point windowSize;

        public Camera3D(Point windowSize, Vector3 position, Vector3 lookat)
        {
            this.windowSize = windowSize;
            _position = position;
            _forward = lookat - position;
            _forward.Normalize();
        }

        public Vector3 Position
        {
            get
            {
                return _position;
            }
            set
            {
                if (_position != value)
                {
                    _position = value;
                    HasChanged = true;
                    HasMoved = true;
                }
            }
        }

        public Vector3 Up
        {
            get
            {
                return _up;
            }
            set
            {
                if (_up != value)
                {
                    _up = value;
                    HasChanged = true;
                }
            }
        }

        public Vector3 Forward
        {
            get
            {
                return _forward;
            }
            set
            {
                if (_forward != value)
                {
                    _forward = value;
                    HasChanged = true;
                }
            }
        }

        public float FieldOfView
        {
            get { return _fieldOfView; }
            set
            {
                _fieldOfView = value;
                HasChanged = true;
            }
        }

        public Vector3 Lookat
        {
            get { return Position + Forward; }
            set
            {
                Forward = value - Position;
                Forward.Normalize();
            }
        }

        public Matrix View
        {
            get
            {
                return Matrix.CreateLookAt(Position, Position + Lookat, Up);
            }
        }

        public Matrix Projection
        {
            get {
                return Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, (float)windowSize.X / (float)windowSize.Y, 1, 100);
            }
        }

        public void Update(float deltaTime)
        {
            MouseEvents();
            KeyboardEvents(deltaTime);
        }

        private void MouseEvents()
        {
            float mouseAmount = 0.01f;

            Vector3 direction = Forward;
            direction.Normalize();

            Vector3 normal = Vector3.Cross(direction, Up);

            if (Input.GetLeftMousePressed())
            {
                Point mouseDelta = Input.GetMousePositionDelta();
                float y = mouseDelta.Y;
                float x = mouseDelta.X;

                y *= windowSize.Y / 800.0f; //why these numbers?
                x *= windowSize.X / 1280.0f;

                Forward += x * mouseAmount * normal;

                Forward -= y * mouseAmount * Up;
                Forward.Normalize();
            }

        }

        private void KeyboardEvents(float deltaTime)
        {                        
            Vector3 direction = Forward;
            direction.Normalize();

            Vector3 normal = Vector3.Cross(direction, Up);

            float amount = 20f * deltaTime;

            float amountNormal = 4f * deltaTime;
            
            if (Input.GetKeyPressed(Keys.W))
            {
                Position += direction * amount;
            }

            if (Input.GetKeyPressed(Keys.S))
            {
                Position -= direction * amount;
            }

            if (Input.GetKeyPressed(Keys.D))
            {
                Position += normal * amountNormal;
            }

            if (Input.GetKeyPressed(Keys.A))
            {
                Position -= normal * amountNormal;
            }
        }

    }



    /*
    public class Camera3D
    {
        public Matrix view { get; protected set; }
        public Matrix projection { get; protected set; }

        public Vector3 cameraPosition { get; protected set; }
        Vector3 cameraDirection;
        Vector3 cameraUp;

        //defines speed of camera movement
        float speed = 0.5F;

        MouseState prevMouseState;
        Point windowSize;
        Point halfWindowSize;

        public Camera3D(Point windowSize, Vector3 pos, Vector3 target, Vector3 up)            
        {
            // TODO: Construct any child components here
            this.windowSize = windowSize;
            this.halfWindowSize = new Point(windowSize.X / 2, windowSize.Y / 2);
            // Build camera view matrix
            cameraPosition = pos;
            cameraDirection = target - pos;
            cameraDirection.Normalize();
            cameraUp = up;
            CreateLookAt();

            projection = Matrix.CreatePerspectiveFieldOfView(MathHelper.PiOver4, (float)windowSize.X / (float)windowSize.Y, 1, 100);
        }

    
        public void Initialize()
        {
            // Set mouse position and do initial get state
            Mouse.SetPosition(halfWindowSize.X, halfWindowSize.Y);
            prevMouseState = Mouse.GetState();
        }
       
        public void Update(GameTime gameTime)
        {
            // TODO: Add your update code here


            // Move forward and backward

           
            if (Keyboard.GetState().IsKeyDown(Keys.W))
                cameraPosition += cameraDirection * speed;
            if (Keyboard.GetState().IsKeyDown(Keys.S))
                cameraPosition -= cameraDirection * speed;

            if (Keyboard.GetState().IsKeyDown(Keys.A))
                cameraPosition += Vector3.Cross(cameraUp, cameraDirection) * speed;
            if (Keyboard.GetState().IsKeyDown(Keys.D))
                cameraPosition -= Vector3.Cross(cameraUp, cameraDirection) * speed;
            
            

            



            // Rotation in the world
            cameraDirection = Vector3.Transform(cameraDirection, Matrix.CreateFromAxisAngle(cameraUp, (-MathHelper.PiOver4 / 150) * (Mouse.GetState().X - prevMouseState.X)));


            cameraDirection = Vector3.Transform(cameraDirection, Matrix.CreateFromAxisAngle(Vector3.Cross(cameraUp, cameraDirection), (MathHelper.PiOver4 / 100) * (Mouse.GetState().Y - prevMouseState.Y)));
            cameraUp = Vector3.Transform(cameraUp, Matrix.CreateFromAxisAngle(Vector3.Cross(cameraUp, cameraDirection), (MathHelper.PiOver4 / 100) * (Mouse.GetState().Y - prevMouseState.Y)));

            // Reset prevMouseState
            prevMouseState = Mouse.GetState();
            Mouse.SetPosition(halfWindowSize.X, halfWindowSize.Y);

            CreateLookAt();

        }

        private void CreateLookAt()
        {
            view = Matrix.CreateLookAt(cameraPosition, cameraPosition + cameraDirection, cameraUp);
        }

    }
    */
}