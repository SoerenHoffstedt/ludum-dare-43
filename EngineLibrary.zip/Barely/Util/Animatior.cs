﻿using System.Collections.Generic;

namespace Barely.Util {
    public static class Animator {

        static HashSet<Sprite> sprites = new HashSet<Sprite>();



        public static void AddSprite(Sprite sprite) {
            if(sprites.Contains(sprite) == false)
                sprites.Add(sprite);
        }

        public static void RemoveSprite(Sprite sprite) {
            sprites.Remove(sprite);
        }

        public static void Update(double dt) {
            foreach(Sprite sprite in sprites)
            {
                sprite.Update(dt);
            }
        }


    }
}
