﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Util {

    public class Sprite9Slice : Sprite {

        Rectangle sliceRect;
        int leftSlice;
        int rightSlice;
        int upSlice;
        int downSlice;


        public Sprite9Slice(Texture2D atlas, Rectangle spriteRect, int left, int right, int up, int down) 
            : this(atlas, spriteRect, Color.White, left, right, up, down, null) { }

        public Sprite9Slice(Texture2D atlas, Rectangle spriteRect, Color color, int left, int right, int up, int down, Animation animation = null) 
            : base(atlas, spriteRect, color, animation) {
            this.spriteRect = spriteRect;
            leftSlice = left;
            rightSlice = right;
            upSlice = up;
            downSlice = down;
        }

        public override void Render(SpriteBatch spriteBatch, Rectangle destination) {
            Render(spriteBatch, destination, color);        
        }


        // i restrict the drawing horizontally if the destination width is smaller equal the left slice. 
        // this could be done way more intrecAte and right for every dimension and for the right etc, but i dont care.
        // this is done for the level up progress bar animation for the tactics game.

        public override void Render(SpriteBatch spriteBatch, Rectangle destination, Color col) {
            //base.Render(spriteBatch, atlas, destination);

            destination.Location += drawOffset;

            int w = destination.Width;
            int h = destination.Height;

            int leftPart = leftSlice;
            if (leftSlice > w)
                leftPart = w;

            //left upper corner
            spriteBatch.Draw(atlas, new Rectangle(destination.X, destination.Y, leftPart, upSlice),
                new Rectangle(spriteRect.X, spriteRect.Y, leftPart, upSlice), col);

            //left part
            spriteBatch.Draw(atlas, new Rectangle(destination.X, destination.Y + upSlice, leftPart, destination.Height - downSlice - upSlice),
                new Rectangle(spriteRect.X, spriteRect.Y + upSlice, leftPart, spriteRect.Height - downSlice - upSlice), col);

            //left down corner
            spriteBatch.Draw(atlas, new Rectangle(destination.X, destination.Y + destination.Height - downSlice, leftPart, downSlice),
                new Rectangle(spriteRect.X, spriteRect.Y + spriteRect.Height - downSlice, leftPart, downSlice), col);

            if (w <= leftSlice)
                return;
            
            if(w - leftSlice - rightSlice >= 0)
            {
                //middle upper part
                spriteBatch.Draw(atlas, new Rectangle(destination.X + leftSlice, destination.Y, destination.Width - leftSlice - rightSlice, upSlice),
                    new Rectangle(spriteRect.X + leftSlice, spriteRect.Y, spriteRect.Width - leftSlice - rightSlice, upSlice), col);

                //middle middle stretch
                spriteBatch.Draw(atlas, new Rectangle(destination.X + leftSlice, destination.Y + upSlice, destination.Width - leftSlice - rightSlice, destination.Height - upSlice - downSlice),
                    new Rectangle(spriteRect.X + leftSlice, spriteRect.Y + upSlice, spriteRect.Width - leftSlice - rightSlice, spriteRect.Height - upSlice - downSlice), col);

                //middle down part
                spriteBatch.Draw(atlas, new Rectangle(destination.X + leftSlice, destination.Y + destination.Height - downSlice, destination.Width - leftSlice - rightSlice, downSlice),
                    new Rectangle(spriteRect.X + leftSlice, spriteRect.Y + spriteRect.Height - downSlice, spriteRect.Width - leftSlice - rightSlice, downSlice), col);
            }



            //right upper corner
            spriteBatch.Draw(atlas, new Rectangle(destination.X + destination.Width - rightSlice, destination.Y, rightSlice, upSlice),
                new Rectangle(spriteRect.X + spriteRect.Width - rightSlice, spriteRect.Y, rightSlice, upSlice), col);  

            //right middle part
            spriteBatch.Draw(atlas, new Rectangle(destination.X + destination.Width - rightSlice, destination.Y + upSlice, rightSlice, destination.Height - upSlice - downSlice),
                new Rectangle(spriteRect.X + spriteRect.Width - rightSlice, spriteRect.Y + upSlice, rightSlice, spriteRect.Height - upSlice - downSlice), col);

            //right down corner
            spriteBatch.Draw(atlas, new Rectangle(destination.X + destination.Width - rightSlice, destination.Y + destination.Height - downSlice, rightSlice, downSlice),
                new Rectangle(spriteRect.X + spriteRect.Width - rightSlice, spriteRect.Y + spriteRect.Height - downSlice, rightSlice, downSlice), col);

        }

        public override Sprite CopyInstance() {
            return new Sprite9Slice(atlas, spriteRect, color, leftSlice, rightSlice, upSlice, downSlice, animation?.CopyInstance());
        }


    }
}
