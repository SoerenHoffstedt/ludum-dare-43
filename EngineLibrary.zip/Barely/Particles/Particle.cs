﻿using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;

namespace Barely.Particles
{
    public class Particle
    {
        Vector3 position;
        Vector3 movement;
        Sprite sprite; 

    }
}
