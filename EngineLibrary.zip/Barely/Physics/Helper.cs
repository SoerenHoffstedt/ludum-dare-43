﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics
{
    internal static class Helper
    {

        internal static Vector2 MultiplyVector2With2x2Matrix(Vector2 v, float[] matrix2x2)
        {
            float x = v.X * matrix2x2[0] + v.Y * matrix2x2[2];
            float y = v.X * matrix2x2[1] + v.Y * matrix2x2[3];
            return new Vector2(x, y);
        }

        internal static float[] GetRotationMatrix(float theta)
        {
            return new float[] { (float)Math.Cos(theta), (float)Math.Sin(theta),
                                -(float)Math.Sin(theta), (float)Math.Cos(theta) };
        }

    }
}
