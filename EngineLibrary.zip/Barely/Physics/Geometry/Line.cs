﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics.Geometry
{
    public struct Line
    {
        public Vector2 start;
        public Vector2 end;

        public Line(Vector2 start, Vector2 end)
        {
            this.start = start;
            this.end = end;
        }

        public float Length()
        {
            return (end - start).Length();
        }

        public float LengthSquared()
        {
            return (end - start).LengthSquared();
        }
    }
}
