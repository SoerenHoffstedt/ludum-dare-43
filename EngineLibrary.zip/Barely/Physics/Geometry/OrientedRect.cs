﻿using Barely.Physics.Overlap;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics.Geometry
{
    public struct OrientedRect : Shape2D
    {
        public Vector2 position;
        public Vector2 halfExtent;
        public float rotation;

        public OrientedRect(Vector2 position, Vector2 halfExtent, float rotation)
        {
            this.position = position;
            this.halfExtent = halfExtent;
            this.rotation = rotation;
        }

        public OrientedRect(Vector2 position, Vector2 halfExtent)
        {
            this.position = position;
            this.halfExtent = halfExtent;
            this.rotation = 0f;
        }

        public Vector2 TransformPointToLocalSpace(Vector2 p)
        {
            Vector2 r = p - position;
            float theta = -MathHelper.ToRadians(rotation);
            float[] zRotation2x2 = Helper.GetRotationMatrix(theta);
            r = Helper.MultiplyVector2With2x2Matrix(r, zRotation2x2);
            
            return r + halfExtent;
        }

        public Rect TransformToLocalRect()
        {
            return new Rect(Vector2.Zero, halfExtent * 2.0f);
        }

        public float[] GetRotationMatrix()
        {
            return Helper.GetRotationMatrix(-MathHelper.ToRadians(rotation));
        }

        public Interval2D GetInterval(Vector2 axis)
        {
            Interval2D result;
            Rect r = new Rect(position - halfExtent, halfExtent * 2f);
            Vector2 min = r.Min;
            Vector2 max = r.Max;
            Vector2[] verts = { new Vector2(min.X, min.Y), new Vector2(min.X, max.Y), new Vector2(max.X, max.Y), new Vector2(max.X, min.Y) };

            float t = MathHelper.ToRadians(rotation);
            float[] zRot = Helper.GetRotationMatrix(t);
            for (int i = 0; i < 4; i++)
            {
                Vector2 re = verts[i] - position;
                re = Helper.MultiplyVector2With2x2Matrix(re, zRot);                
                verts[i] = re + position;
            }

            result.min = result.max = Vector2.Dot(axis, verts[0]);
            for (int i = 1; i < 4; i++)
            {
                float projection = Vector2.Dot(axis, verts[i]);
                if (projection < result.min)
                    result.min = projection;
                if (projection > result.max)
                    result.max = projection;
            }
            return result;
        }

        public bool Collides(Circle c)
        {
            return Collision.Collides(c, this);
        }

        public bool Collides(Rect r)
        {
            return Collision.Collides(this, r);
        }

        public bool Collides(OrientedRect o)
        {
            return Collision.Collides(o, this);
        }

        public bool Collides(BoundingShape bs)
        {
            return Collision.Collides(bs, this);
        }
    }
}
