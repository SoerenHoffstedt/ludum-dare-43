﻿using Barely.Physics.Overlap;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics.Geometry
{
    public struct Circle : Shape2D
    {
        public Vector2 position;
        public float radius;

        public Circle(Vector2 position, float radius)
        {
            this.position = position;
            this.radius = radius;
        }


        public static Circle CreateContainingCircle(List<Vector2> points)
        {
            Vector2 center = new Vector2();
            foreach(Vector2 v in points)
            {
                center = center + v;
            }

            center = center * (1.0f / points.Count);
            Circle c = new Circle(center, 1f);

            // get Radius (largest distance from center to a point)
            c.radius = (center - points[0]).LengthSquared();
            for (int i = 1; i < points.Count; i++)
            {
                float d = (center - points[i]).LengthSquared();
                if (d > c.radius)
                    c.radius = d;
            }
            c.radius = (float)Math.Sqrt(c.radius);
            return c;
        }

        public bool Collides(Circle c)
        {
            return Collision.Collides(this, c);
        }

        public bool Collides(Rect r)
        {
            return Collision.Collides(this, r);
        }

        public bool Collides(OrientedRect o)
        {
            return Collision.Collides(this, o);
        }

        public bool Collides(BoundingShape bs)
        {
            return Collision.Collides(bs, this);
        }

    }
}
