﻿using Barely.Physics.Overlap;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics.Geometry
{
    public class BoundingShape : Shape2D
    {

        public Circle[] circles;
        public Rect[] rects;

        public BoundingShape(Circle[] c, Rect[] r)
        {
            circles = c;
            rects = r;
        }

        public bool Collides(Circle c)
        {
            return Collision.Collides(this, c);
        }

        public bool Collides(Rect r)
        {
            return Collision.Collides(this, r);
        }

        public bool Collides(OrientedRect o)
        {
            return Collision.Collides(this, o);
        }

        public bool Collides(BoundingShape bs)
        {
            foreach(Circle c in circles)
            {
                if (Collision.Collides(bs, c))
                    return true;
            }

            foreach (Rect r in rects)
            {
                if (Collision.Collides(bs, r))
                    return true;
            }

            return false;
        }

    }
}
