﻿using Barely.Physics.Geometry;
using Microsoft.Xna.Framework;
using System;

namespace Barely.Physics.Overlap
{
    public static class LineIntersection
    {

        public static bool Intersects(Line l, Circle c)
        {
            Vector2 ab = l.end - l.start;
            float t = Vector2.Dot(c.position - l.start, ab) / Vector2.Dot(ab, ab);
            if(t < 0.0f || t > 1.0f)
                return false;
            Vector2 closestPoint = l.start + ab * t;
            Line circleToClosest = new Line(c.position, closestPoint);
            return circleToClosest.LengthSquared() < c.radius * c.radius;            
        }

        public static bool Intersects(Line l, Rect r)
        {
            if (PointContainment.Contains(r, l.start) || PointContainment.Contains(r, l.end))
                return true;

            //Line direction
            Vector2 norm = Vector2.Normalize(l.end - l.start);
            norm.X = (norm.X != 0) ? 1.0f / norm.X : 0;
            norm.Y = (norm.Y != 0) ? 1.0f / norm.Y : 0;

            Vector2 min = (r.Min - l.start) * norm;
            Vector2 max = (r.Max - l.start) * norm;

            float tMin = Math.Max(Math.Min(min.X, max.X), Math.Min(min.Y, max.Y));
            float tMax = Math.Min(Math.Max(min.X, max.X), Math.Max(min.Y, max.Y));
            if (tMax < 0 || tMin > tMax)
                return false;
            float t = tMin < 0.0f ? tMax : tMin;
            return t > 0.0f && t * t < l.LengthSquared();

        }

        public static bool Intersects(Line line, OrientedRect rect)
        {
            throw new NotImplementedException();
        }

    }
}
