﻿using Barely.Physics.Geometry;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics.Overlap
{
    public static class Collision
    {

        public static bool Collides(BoundingShape bs, Circle c)
        {
            foreach (Circle circle in bs.circles)
            {
                if (Collides(circle, c))
                    return true;
            }

            foreach (Rect rect in bs.rects)
            {
                if (Collides(c, rect))
                    return true;
            }

            return false;
        }

        public static bool Collides(BoundingShape bs, Rect r)
        {
            foreach (Circle circle in bs.circles)
            {
                if (Collides(circle, r))
                    return true;
            }

            foreach (Rect rect in bs.rects)
            {
                if (Collides(rect, r))
                    return true;
            }

            return false;
        }

        public static bool Collides(BoundingShape bs, OrientedRect o)
        {
            foreach (Circle circle in bs.circles)
            {
                if (Collides(circle, o))
                    return true;
            }

            foreach (Rect rect in bs.rects)
            {
                if (Collides(rect, o))
                    return true;
            }

            return false;
        }

        public static bool Collides(Circle c1, Circle c2)
        {
            Line l = new Line(c1.position, c2.position);
            float radiiSum = c1.radius + c2.radius;
            return l.LengthSquared() <= radiiSum * radiiSum;
        }

        public static bool Collides(Circle c, Rect r)
        {
            Vector2 min = r.Min;
            Vector2 max = r.Max;

            Vector2 closestPoint = c.position;

            if (closestPoint.X < min.X)
                closestPoint.X = min.X;
            else if (closestPoint.X > max.X)
                closestPoint.X = max.X;

            if (closestPoint.Y < min.Y)
                closestPoint.Y = min.Y;
            else if (closestPoint.Y > max.Y)
                closestPoint.Y = max.Y;

            Line line = new Line(c.position, closestPoint);
            return line.LengthSquared() <= c.radius * c.radius;

        }
        public static bool Collides(OrientedRect rect, Circle circle)
        {
            return Collides(circle, rect);
        }

        public static bool Collides(Circle circle, OrientedRect rect)
        {
            Vector2 localCirclePosition = rect.TransformPointToLocalSpace(circle.position);
            Rect localRect = rect.TransformToLocalRect();
            Circle localCircle = new Circle(localCirclePosition, circle.radius);
            return Collides(localCircle, localRect);
        }

        public static bool Collides(Rect rect1, Rect rect2)
        {
            Vector2 aMin = rect1.Min;
            Vector2 aMax = rect1.Max;
            Vector2 bMin = rect2.Min;
            Vector2 bMax = rect2.Max;
            bool overX = bMin.X <= aMax.X && aMin.X <= bMax.X;
            bool overY = bMin.Y <= aMax.Y && aMin.Y <= bMax.Y;
            return overX && overY;
        }

        public static bool Collides(Rect rect1, OrientedRect rect2)
        {
            Vector2[] axis = { new Vector2(1, 0), new Vector2(0, 1), new Vector2(), new Vector2() };
            float t = MathHelper.ToRadians(rect2.rotation);
            float[] zRot = { (float)Math.Cos(t), (float)Math.Sin(t), (float)-Math.Sin(t), (float)Math.Cos(t) };

            Vector2 a = Vector2.Normalize(new Vector2(rect2.halfExtent.X, 0));
            Vector2 ax2 = Helper.MultiplyVector2With2x2Matrix(a, zRot);
            axis[2] = ax2;

            a = Vector2.Normalize(new Vector2(0, rect2.halfExtent.Y));
            Vector2 ax3 = Helper.MultiplyVector2With2x2Matrix(a, zRot);
            axis[3] = ax3;

            for (int i = 0; i < 4; i++)
            {
                if (!OverlapOnAxis(rect1, rect2, axis[i]))
                    return false;
            }
            return true;
        }

        public static bool Collides(OrientedRect rect2, Rect rect1)
        {
            return Collides(rect1, rect2);
        }

        public static bool Collides(OrientedRect r1, OrientedRect r2)
        {
            Rect local1 = new Rect(new Vector2(), r1.halfExtent * 2f);
            Vector2 r = r2.position - r1.position;
            OrientedRect local2 = new OrientedRect(r2.position, r2.halfExtent, r2.rotation);
            local2.rotation = r2.rotation - r1.rotation;
            float[] z = r1.GetRotationMatrix();
            r = Helper.MultiplyVector2With2x2Matrix(r, z);
            local2.position = r + r1.halfExtent;
            return Collides(local1, local2);
        }

        private static bool OverlapOnAxis(Rect rect1, OrientedRect rect2, Vector2 axis)
        {
            Interval2D a = rect1.GetInterval(axis);
            Interval2D b = rect2.GetInterval(axis);
            return b.min <= a.max && a.min <= b.max;
        }

        private static bool OverlapOnAxis(Rect rect1, Rect rect2, Vector2 axis)
        {
            Interval2D a = rect1.GetInterval(axis);
            Interval2D b = rect2.GetInterval(axis);
            return b.min <= a.max && a.min <= b.max;
        }

        private static bool RectangleRectangleSAT(Rect rect1, Rect rect2)
        {
            Vector2[] axisToTest = { new Vector2(1,0), new Vector2(0,1) };
            for (int i = 0; i < 2; i++)
            {
                if (!OverlapOnAxis(rect1, rect2, axisToTest[i]))
                    return false;
            }
            return true;
        }

    }
}
