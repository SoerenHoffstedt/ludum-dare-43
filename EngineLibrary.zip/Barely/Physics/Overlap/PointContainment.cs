﻿using Barely.Physics.Geometry;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics.Overlap
{
    public static class PointContainment
    {

        internal static bool Compare(float a, float b)
        {
            throw new NotImplementedException();
        }

        public static bool Contains(Line l, Vector2 p)
        {
            float dy = l.end.Y - l.start.Y;
            float dx = l.end.X - l.start.X;
            float M = dy / dx;
            float B = l.start.Y - M * l.start.X;
            return Compare(p.Y, M * p.X + B);
        }

        public static bool Contains(Circle c, Vector2 p)
        {
            Line l = new Line(p, c.position);
            return l.LengthSquared() < c.radius * c.radius;
                
        }

        public static bool Contains(Rect r, Vector2 p)
        {
            Vector2 min = r.Min;
            Vector2 max = r.Max;
            return min.X <= p.X && min.Y <= p.Y &&
                   p.X <= max.X && p.Y <= max.Y;
        }

        public static bool Contains(OrientedRect r, Vector2 p)
        {            
            Rect localRect = r.TransformToLocalRect();
            Vector2 localPoint = r.TransformPointToLocalSpace(p);
            return PointContainment.Contains(localRect, localPoint);
        }

    }

}
