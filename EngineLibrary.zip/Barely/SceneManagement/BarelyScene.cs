﻿using Barely.Interface;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;


namespace Barely.SceneManagement
{

    public abstract class BarelyScene
    {
        protected Game game;
        protected ContentManager Content;
        protected GraphicsDevice GraphicsDevice;
        protected Camera camera;
        public InterfaceManager ifManager;

        public BarelyScene(ContentManager Content, GraphicsDevice GraphicsDevice, Game game) {
            this.game               = game;
            this.Content            = Content;
            this.GraphicsDevice     = GraphicsDevice;
            this.camera             = new Camera(GraphicsDevice.Viewport, 1f, 1f);
        }

        public abstract void Initialize();
        public abstract void Update(double deltaTime);
        public abstract void Draw(SpriteBatch spriteBatch);        

        protected MouseState lastMouseState;
        protected KeyboardState lastKeyboardState;
        protected bool isDragging;
        protected bool clickedThisFrame;

        protected abstract void CameraInput(double deltaTime);

    }
}
