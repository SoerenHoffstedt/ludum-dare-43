﻿using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BarelyUI.Styles
{
    public class StyleSheet
    {
        #region Data Fields
        public StyleSheet CurrentParentStyle { get; internal set; }

        internal string id;

        // Text
        private SpriteFont textFont;
        private Color? textColor;

        // Button
        private Sprite buttonSprite;
        private Color[] buttonColors;
        private SpriteFont buttonFont;
        private Color? buttonTextColor;

        // Panel
        private bool?  panelHasSprite;
        private Sprite panelSprite;

        // Checkbox
        private Sprite checkboxSprite;
        private Sprite checkboxSelectionSprite;

        // RadioButton
        private Sprite radioButtonSprite;
        private Sprite radioButtonSelectionSprite;
        private SpriteFont radioButtonFont;
        private Color? radioButtonTextColor;

        // Scrollbar
        private Sprite scrollbarSprite;
        private Sprite scrollbarHandleSprite;

        private Color? keyTextColor;
        private Color? valueTextColor;
        private SpriteFont keyTextFont;
        private SpriteFont valueTextFont;

        //Titlebar
        private Sprite titlebarSprite;
        private Sprite titlebarCloseSprite;
        private Color? titlebarTextColor;
        private SpriteFont titlebarFont;

        //Slider
        private Sprite sliderHandleSprite;
        private Sprite sliderBarSprite;

        #endregion

        #region Getter

        //Slider
        public Sprite GetSliderHandleSprite()
        {
            return sliderHandleSprite != null ? sliderHandleSprite : CurrentParentStyle.GetSliderHandleSprite();
        } 

        public Sprite GetSliderBarSprite()
        {
            return sliderBarSprite != null ? sliderBarSprite : CurrentParentStyle.GetSliderBarSprite();
        }

        // Text
        public SpriteFont GetTextFont()
        {
            return textFont != null ? textFont : CurrentParentStyle.GetTextFont();            
        }

        public Color GetTextColor()
        {
            return textColor != null ? textColor.Value : CurrentParentStyle.GetTextColor();
        }

        // Button
        public Sprite GetButtonSprite()
        {
            return buttonSprite != null ? buttonSprite : CurrentParentStyle.GetButtonSprite();
        }

        public Color[] GetButtonColors()
        {
            return buttonColors != null ? buttonColors : CurrentParentStyle.GetButtonColors();
        }

        public SpriteFont GetButtonFont()
        {
            return buttonFont != null ? buttonFont : CurrentParentStyle.GetButtonFont();
        }

        public Color GetButtonTextColor()
        {
            return buttonTextColor != null ? buttonTextColor.Value : CurrentParentStyle.GetButtonTextColor();
        }

        // Panel
        public bool GetPanelHasSprite()
        {
            return panelHasSprite != null ? panelHasSprite.Value : CurrentParentStyle.GetPanelHasSprite();
        }

        public Sprite GetPanelSprite()
        {
            return panelSprite != null ? panelSprite : CurrentParentStyle.GetPanelSprite();
        }

        // Checkbox
        public Sprite GetCheckboxSprite()
        {
            return checkboxSprite != null ? checkboxSprite : CurrentParentStyle.GetCheckboxSprite();
        }

        public Sprite GetCheckboxSelectionSprite()
        {
            return checkboxSelectionSprite != null ? checkboxSelectionSprite : CurrentParentStyle.GetCheckboxSelectionSprite();
        }        

        // RadioButton
        public Sprite GetRadioButtonSprite()
        {
            return radioButtonSprite != null ? radioButtonSprite : CurrentParentStyle.GetRadioButtonSprite();
        }        

        public Sprite GetRadioButtonSelectionSprite()
        {
            return radioButtonSelectionSprite != null ? radioButtonSelectionSprite : CurrentParentStyle.GetRadioButtonSelectionSprite();
        }

        public SpriteFont GetRadioButtonFont()
        {
            return radioButtonFont != null ? radioButtonFont : CurrentParentStyle.GetRadioButtonFont();
        }

        public Color GetRadioButtonTextColor()
        {
            return radioButtonTextColor != null ? radioButtonTextColor.Value : CurrentParentStyle.GetRadioButtonTextColor();
        }

        // Scrollbar
        public Sprite GetScrollbarSprite()
        {
            return scrollbarSprite != null ? scrollbarSprite : CurrentParentStyle.GetScrollbarSprite();
        }

        public Sprite GetScrollbarHandleSprite()
        {
            return scrollbarHandleSprite != null ? scrollbarHandleSprite : CurrentParentStyle.GetScrollbarHandleSprite();
        }

        // Key Value Text
        public Color GetKeyTextColor()
        {
            return keyTextColor != null ? keyTextColor.Value : CurrentParentStyle.GetKeyTextColor();
        }

        public Color GetValueTextColor()
        {
            return valueTextColor != null ? valueTextColor.Value : CurrentParentStyle.GetValueTextColor();
        }

        public SpriteFont GetKeyFont()
        {
            return keyTextFont != null ? keyTextFont : CurrentParentStyle.GetKeyFont();
        }

        public SpriteFont GetValueFont()
        {
            return valueTextFont != null ? valueTextFont : CurrentParentStyle.GetValueFont();
        }

        // Titlebar
        public Sprite GetTitlebarSprite()
        {
            return titlebarSprite != null ? titlebarSprite : CurrentParentStyle.GetTitlebarSprite();
        }

        public Sprite GetTitlebarCloseSprite()
        {
            return titlebarCloseSprite != null ? titlebarCloseSprite : CurrentParentStyle.GetTitlebarCloseSprite();
        }

        public Color GetTitlebarTextColor()
        {
            return titlebarTextColor != null ? titlebarTextColor.Value : CurrentParentStyle.GetTitlebarTextColor();
        }

        public SpriteFont GetTitlebarFont()
        {
            return titlebarFont != null ? titlebarFont : CurrentParentStyle.GetTitlebarFont();
        }

        #endregion

        internal static StyleSheet LoadFromXml(XmlNode n, Dictionary<string, Sprite> sprites, Dictionary<string, Color> colors, Dictionary<string, SpriteFont> fonts, string name)
        {
            StyleSheet sh = new StyleSheet();
            sh.id = name;

            sh.textColor            = GetColor(colors, n, "textColor");
            sh.textFont             = GetFont(fonts, n, "textFont");

            var panelSpriteNode = n.SelectSingleNode("panelHasSprite");
            if(panelSpriteNode != null)
            sh.panelHasSprite       = bool.Parse(panelSpriteNode.Attributes["val"].Value);

            sh.panelSprite          = GetSprite(sprites, n, "panelSprite");
            sh.buttonSprite         = GetSprite(sprites, n, "buttonSprite");
            sh.buttonFont           = GetFont(fonts, n, "buttonFont");
            sh.buttonTextColor      = GetColor(colors, n, "buttonTextColor");

            
            XmlNode colorNode       = n.SelectSingleNode("buttonColors");
            if(colorNode != null)
            {
                sh.buttonColors = new Color[] { GetColor(colors, colorNode, "normal").Value,
                                                GetColor(colors, colorNode, "mouseOver").Value,
                                                GetColor(colors, colorNode, "mouseDown").Value,
                                                GetColor(colors, colorNode, "inactive").Value
                                              };
            }            

            sh.checkboxSprite               = GetSprite(sprites, n, "checkboxSprite");
            sh.checkboxSelectionSprite      = GetSprite(sprites, n, "checkboxSelectionSprite");

            sh.radioButtonSprite            = GetSprite(sprites, n, "radioButtonSprite");
            sh.radioButtonSelectionSprite   = GetSprite(sprites, n, "radioButtonSelectionSprite");
            sh.radioButtonFont              = GetFont(fonts, n, "radioButtonFont");
            sh.radioButtonTextColor         = GetColor(colors, n, "radioButtonTextColor");

            sh.scrollbarSprite              = GetSprite(sprites, n, "scrollbarSprite");
            sh.scrollbarHandleSprite        = GetSprite(sprites, n, "scrollbarHandleSprite");

            sh.keyTextFont                  = GetFont(fonts, n, "keyTextFont");
            sh.valueTextFont                = GetFont(fonts, n, "valueTextFont");
            sh.keyTextColor                 = GetColor(colors, n, "keyTextColor");
            sh.valueTextColor               = GetColor(colors, n, "valueTextColor");

            sh.titlebarSprite               = GetSprite(sprites, n, "titlebarSprite");
            sh.titlebarCloseSprite          = GetSprite(sprites, n, "titlebarCloseSprite");
            sh.titlebarFont                 = GetFont(fonts, n, "titlebarFont");
            sh.titlebarTextColor            = GetColor(colors, n, "titlebarTextColor");

            sh.sliderHandleSprite           = GetSprite(sprites, n, "sliderHandle");
            sh.sliderBarSprite              = GetSprite(sprites, n, "sliderBar");

            return sh;
        }

        private static Sprite GetSprite(Dictionary<string,Sprite> sprites, XmlNode n, string node)
        {
            XmlNode newNode = n.SelectSingleNode(node);
            if (newNode != null)
                return sprites[newNode.Attributes["id"].Value];
            else
                return null;
        }

        private static Color? GetColor(Dictionary<string, Color> colors, XmlNode n, string node)
        {
            XmlNode newNode = n.SelectSingleNode(node);
            if (newNode != null)
                return colors[newNode.Attributes["id"].Value];
            else
                return null;
        }

        private static SpriteFont GetFont(Dictionary<string, SpriteFont> fonts, XmlNode n, string node)
        {
            XmlNode newNode = n.SelectSingleNode(node);
            if (newNode != null)
                return fonts[newNode.Attributes["id"].Value];
            else
                return null;
        }


    }
}
