﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarelyUI.Styles
{
    public class StyleException : Exception
    {

        public StyleException(string msg) : base(msg) { }

    }
}
