﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarelyUI
{
    public class VerticalLayout : Panel
    {
        public VerticalLayout(Point pos, Point size) : base()
        {
            SetFixedSize(size);
            SetPosition(pos);
        }

        public VerticalLayout() : base()
        {            
            
        }
     
        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            base.SetSizeAndPosition(canvas, position, size);

            int matchParentElements = 0;
            childElements.ForEach((e) => { if (e.layoutSizeY == LayoutSize.MatchParent) matchParentElements++; });            
                      
            int yToFill     = Size.Y - WrappingMinSize.Y;
            int perToFill   = matchParentElements == 0 ? 0 : yToFill / matchParentElements;
            int restToFill  = matchParentElements == 0 ? 0 : yToFill % matchParentElements;
            
            Point p = Padding;
            for (int i = 0; i < childElements.Count; i++)
            {
                UIElement e = childElements[i];
                if(overwriteChildLayout)
                    e.layoutSizeX = childLayoutOverwrite;
                size = Size - new Point(Padding.X * 2, p.Y);
                
                if (hasScrollbar)
                    size.X -= Scrollbar.SIZE + Padding.X;

                if(e.layoutSizeY == LayoutSize.MatchParent)
                {
                    size.Y = perToFill + e.MinSize.Y;
                    if(restToFill > 0)
                    {
                        size.Y += 1;
                        restToFill--;
                    }
                }

                e.SetSizeAndPosition(canvas, p, size);

                if (e.Size.X < childMinSize.X)
                {
                    e.Size = new Point(childMinSize.X, e.Size.Y);
                }
                if (e.Size.Y < childMinSize.Y)
                {
                    e.Size = new Point(e.Size.X, childMinSize.Y);
                }

                if(!overwriteChildLayout || childLayoutOverwrite != LayoutSize.MatchParent)
                {
                    if (childAllignX == AnchorX.Left)
                        e.ChangeXPosition(Padding.X);
                    else if (childAllignX == AnchorX.Middle)
                        e.ChangeXPosition((Size.X - e.Size.X) / 2);
                    else if (childAllignX == AnchorX.Right)
                        e.ChangeXPosition(Size.X - Padding.X - e.Size.X);
                }

                p.Y += Margin;
                p.Y += e.Size.Y;
            }
            p.Y -= Margin;
            p.Y += Padding.Y;

            if (p.Y > Size.Y)
            {
                if(layoutSizeY == LayoutSize.WrapContent)
                   Size = new Point(Size.X, p.Y);                                                                                
            }

            if (p.Y < Size.Y && childAllignY != AnchorY.Top)
            {
                int move = 0;
                if (childAllignY == AnchorY.Middle)
                {
                    move = (Size.Y - p.Y) / 2;
                }
                else if (childAllignY == AnchorY.Bottom)
                {
                    move = Size.Y - p.Y;
                }

                Point pMove = new Point(0, move);

                foreach (UIElement element in childElements)
                {
                    element.Position = element.Position + pMove;
                }
            }

            if (hasScrollbar)
            {
                sizeDifference = new Point(0, p.Y - (Size.Y - Padding.Y - Padding.Y ));
                if (sizeDifference.Y < 0)
                    sizeDifference.Y = 0;
                scrollbar.SetHeights(p.Y, sizeDifference.Y);

                scrollbar.layoutSizeX = LayoutSize.WrapContent;
                scrollbar.layoutSizeY = LayoutSize.MatchParent;
                Point pos = new Point(Size.X - Padding.X - Scrollbar.SIZE, Padding.Y);
                Point sbSize = new Point(Scrollbar.SIZE, Size.Y - 2 * Padding.Y);
                scrollbar.SetSizeAndPosition(canvas, pos, sbSize);
            }

            if (layoutFill != LayoutFill.Nothing && p.Y < Size.Y - 2 * Padding.Y)
            {                
                int toFill = Size.Y - Padding.Y - p.Y;
                int perElement;
                int rest;

                if (layoutFill == LayoutFill.StretchContent)
                {
                    perElement = toFill / childElements.Count;
                    rest = toFill % childElements.Count; //- perElement * childElements.Count;
                }
                else
                {
                    perElement = toFill / (childElements.Count - 1);
                    rest = toFill % (childElements.Count - 1);// - perElement * (childElements.Count - 1);
                }
                int toAdd = 0;                
                for (int i = 0; i < childElements.Count; i++)
                {
                    UIElement e = childElements[i];
                    if(layoutFill == LayoutFill.StretchContent)
                    {
                        Point newSize = new Point(e.Size.X, e.Size.Y + perElement);
                        LayoutSize old = e.layoutSizeY;
                        e.layoutSizeY = LayoutSize.MatchParent;
                        e.SetSizeAndPosition(canvas, e.Position + new Point(0, toAdd), newSize);
                        e.layoutSizeY = old;
                    }
                    else
                        e.ChangeYPosition(e.Position.Y + toAdd);

                    toAdd += perElement;
                    if(rest > 0)
                    {
                        toAdd++;                        
                        rest--;
                    }
                }
                
            }
            if(hasScrollbar)
                AddChild(scrollbar);
            
        }

        public override Point CalculateMinSize(Canvas canvas)
        {            
            
            Point min = new Point(0, 0);
            foreach(UIElement e in childElements)
            {
                Point eMin = e.CalculateMinSize(canvas);
                if (eMin.X > min.X)
                    min.X = eMin.X;
                min.Y += eMin.Y + Margin;
            }
            min.Y -= Margin;
            min += Padding + Padding;
            WrappingMinSize = min;

            if (layoutSizeX == LayoutSize.FixedSize && min.X < Size.X)
                min.X = Size.X;
            if (layoutSizeY == LayoutSize.FixedSize && min.Y < Size.Y)
                min.Y = Size.Y;

            if(layoutSizeX == LayoutSize.MatchParent)
            {
                if (Size.X != 0)
                    min.X = Size.X;
                else
                    min.X = 20;
            }

            if (layoutSizeY == LayoutSize.MatchParent)
            {
                if (Size.Y != 0)
                    min.Y = Size.Y;
                else
                    min.Y = 20;
            }

            MinSize = min;
            return min;
        }
       
    }

}
