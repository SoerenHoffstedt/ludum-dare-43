﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Barely.Util;
using Microsoft.Xna.Framework.Graphics;

namespace BarelyUI
{
    public class Image : UIElement
    {

        public string spriteId;
        Point drawSize;

        public Image(Sprite sprite)
        {
            Interactable = false;
            this.sprite = sprite;
            drawSize = MinSize = Size = sprite.Size;
            layoutSizeX = LayoutSize.FixedSize;
            layoutSizeY = LayoutSize.FixedSize;
        }

        public Image(string spriteId)
        {
            sprite = Styles.Style.sprites[spriteId];
            MinSize = drawSize = sprite.Size;
            layoutSizeX = LayoutSize.FixedSize;
            layoutSizeY = LayoutSize.FixedSize;
        }

        public Image SetSpriteAndSize(Sprite sprite, Point s)
        {
            this.sprite = sprite;
            Size = MinSize = drawSize = s;
            return this;
        }

        public Image SetSpriteAndSize(Sprite sprite)
        {
            this.sprite = sprite;
            Size = MinSize = drawSize = sprite.spriteRect.Size;
            return this;
        }

        public override Point CalculateMinSize(Canvas canvas)
        {
            if(MinSize == Point.Zero)
            {
                if (drawSize != Point.Zero)
                    MinSize = drawSize;
                else
                    MinSize = new Point(12, 12);
            }
            return MinSize;
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            if (!isOpen)
                return;

            Point offset = Point.Zero;
            if(Size.X > drawSize.X)
                offset = new Point((Size.X - drawSize.X) / 2, 0);
            sprite.Render(spriteBatch, new Rectangle(Position + parentPos + scrollOffset + offset, drawSize), color);
        }
    }
}
