﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Barely.Util;
using System.Diagnostics;
using BarelyUI.Styles;
using BarelyUI.Layouts;

namespace BarelyUI
{
    public class Text : UIElement
    {        
        public Allignment allignmentX = Allignment.Left;
        public Allignment allignmentY = Allignment.Middle;
        private string text;
        private string textId;
        private SpriteFont font;
        private Vector2 textOffset;

        public bool wrapText = false;

        private bool getTranslation = true;

        private Func<string> UpdateText;

        public Text(bool getTranslation = true)
        {
            this.getTranslation = getTranslation;
            Interactable = false;
            textId = text = "";

            var style   = Style.GetActiveStyle();
            font        = style.GetTextFont();
            color       = style.GetTextColor();

            var layout  = Layout.GetActiveLayout();
            allignmentX = layout.GetTextAllignmentX();
            allignmentY = layout.GetTextAllignmentY();
            layoutSizeX = layout.GetTextLayoutSizeX();
            layoutSizeY = layout.GetTextLayoutSizeY();
            Padding     = layout.GetTextPadding();
        }

        public Text(string text, bool getTranslation = true)
        {
            this.getTranslation = getTranslation;
            textId = text;
            this.text = getTranslation ? Texts.Get(text) : text;
            Interactable = false;

            var style   = Style.GetActiveStyle();
            font        = style.GetTextFont();
            color       = style.GetTextColor();

            var layout = Layout.GetActiveLayout();
            allignmentX = layout.GetTextAllignmentX();
            allignmentY = layout.GetTextAllignmentY();
            layoutSizeX = layout.GetTextLayoutSizeX();
            layoutSizeY = layout.GetTextLayoutSizeY();
            Padding = layout.GetTextPadding();
        }

        public Text(string text, SpriteFont font, Color color, bool getTranslation = true)
        {
            this.getTranslation = getTranslation;
            textId = text;
            this.text = getTranslation ? Texts.Get(text) : text;
            Interactable = false;
            Padding = new Point(4, 4);
            
            this.font = font;
            this.color = color;

            var layout = Layout.GetActiveLayout();
            allignmentX = layout.GetTextAllignmentX();
            allignmentY = layout.GetTextAllignmentY();
            layoutSizeX = layout.GetTextLayoutSizeX();
            layoutSizeY = layout.GetTextLayoutSizeY();
            Padding = layout.GetTextPadding();
        }               

        public Text SetGetTranslation(bool getTranslation)
        {
            this.getTranslation = getTranslation;
            return this;
        }

        public Text SetText(string textId)
        {
            this.textId = textId;
            this.text = getTranslation ? Texts.Get(textId) : textId;
            CalculateAllignmentOffset();
            return this;
        }

        public Text SetTextUpdateFunction(Func<string> UpdateText)
        {
            this.UpdateText = UpdateText;
            return this;
        }

        public Text SetAllignments(Allignment allignX, Allignment allignY)
        {
            allignmentX = allignX;
            allignmentY = allignY;
            return this;
        }

        public Text SetFont(SpriteFont font)
        {
            this.font = font;
            return this;
        }

        public Text SetColor(Color newColor)
        {
            color = newColor;
            return this;
        }

        public override Point CalculateMinSize(Canvas canvas)
        {            
            MinSize = new Point(2,2) * Padding + (font.MeasureString(text) + new Vector2(0.5f, 0.5f)).ToPoint();
            return MinSize;
        }


        public override void Update(float deltaTime)
        {
            base.Update(deltaTime);

            if (UpdateText != null)
                SetText(UpdateText());
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            spriteBatch.DrawString(font, text, parentPos.ToVector2() + Position.ToVector2() + textOffset, color);

            if (Canvas.DRAW_DEBUG) { 
                Vector2 p = parentPos.ToVector2() + Position.ToVector2();
                spriteBatch.DrawLine(p, p + new Vector2(Size.X, 0), Color.Red);
                spriteBatch.DrawLine(p + new Vector2(Size.X, 0), p + new Vector2(Size.X, Size.Y), Color.Red);
                spriteBatch.DrawLine(p + new Vector2(Size.X, Size.Y), p + new Vector2(0, Size.Y), Color.Red);
                spriteBatch.DrawLine(p + new Vector2(0, Size.Y), p + new Vector2(0, 0), Color.Red);
            }
        }

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            base.SetSizeAndPosition(canvas, position, size);
            CalculateAllignmentOffset();
        }

        protected void CalculateAllignmentOffset()
        {
            Vector2 stringSize = font.MeasureString(text);
            //Vector2 measure = font.MeasureString(text);

            if(wrapText && stringSize.X > Size.X)
            {
                text = WrapText(font, text, Size);
                stringSize = font.MeasureString(text);
            }

            switch (allignmentX)
            {
                                 
                default:
                case Allignment.Left:
                    textOffset.X = 0;
                    break;
                case Allignment.Middle:
                    textOffset.X = Size.X / 2 - stringSize.X / 2;
                    break;
                case Allignment.Right:
                    textOffset.X = Size.X - stringSize.X;
                    break;
               case Allignment.Top:
               case Allignment.Bottom:
                    throw new ArgumentException("X allignment can not be Allignment.Top or Allignment.Bottom.");
            }

            switch (allignmentY)
            {
                default:
                case Allignment.Middle:
                    textOffset.Y = Size.Y / 2 - stringSize.Y / 2;
                    break;             
                case Allignment.Top:
                    textOffset.Y = 0;
                    break;
                case Allignment.Bottom:
                    textOffset.Y = Size.Y - stringSize.Y;
                    break;
                case Allignment.Left:
                case Allignment.Right:
                    throw new ArgumentException("Y allignment can not be Allignment.Left or Allignment.Right.");                    
            }
        }

        private static string WrapText(SpriteFont font, string text, Point maxSize)
        {
            string[] words = text.Split(' ');
            StringBuilder sb = new StringBuilder();
            float maxLineWidth = maxSize.X;
            float maxLineHeight = maxSize.Y;
            float lineWidth = 0f;
            int lines = 0;
            float lineHeight = font.MeasureString("Test Word").Y;
            float spaceWidth = font.MeasureString(" ").X;

            foreach (string word in words)
            {

                Vector2 size = font.MeasureString(word);

                if (word.Contains("\n"))
                {
                    sb.Append(word + " ");
                    lineWidth = size.X + spaceWidth;
                    lines++;
                }
                else if (lineWidth + size.X < maxLineWidth)
                {
                    sb.Append(word + " ");
                    lineWidth += size.X + spaceWidth;
                }
                else
                {
                    if (size.X > maxLineWidth)
                    {
                        if (sb.ToString() == "")
                        {
                            sb.Append(WrapText(font, word.Insert(word.Length / 2, " ") + " ", maxSize));
                        }
                        else
                        {
                            sb.Append("\n" + WrapText(font, word.Insert(word.Length / 2, " ") + " ", maxSize));
                        }
                    }
                    else
                    {
                        if ((lines + 1) * lineHeight >= maxLineHeight)
                        {
                            Debug.WriteLine($"Error in Wrapping text, Height for string not big enough, is cut");
                            return sb.ToString();
                        }
                        sb.Append("\n" + word + " ");
                        lineWidth = size.X + spaceWidth;
                        lines++;
                    }
                }
            }

            return sb.ToString();
        }

    }   

    public enum Allignment
    {
        Top,
        Left,
        Middle,
        Bottom,
        Right
    }

}
