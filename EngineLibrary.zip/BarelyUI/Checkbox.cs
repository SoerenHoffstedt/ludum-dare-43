﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;
using BarelyUI.Styles;

namespace BarelyUI
{
    public class Checkbox : UIElement
    {
        bool isSelected;
        Action<bool> OnSelectionChange;
        Button checkbox;
        Image selectedSprite;
        Text label;

        public int Margin = 10;

        private Point size = new Point(32, 32);

        //The style can be passed if 
        public Checkbox(string text, Action<bool> OnSelectionChange, bool isRadioButton = false, bool startValue = false)
        {            
            var style = Styles.Style.GetActiveStyle();

            autoAdjustPosSizeOfChilds = false;
            Padding = new Point(0, 0);
            this.OnSelectionChange = OnSelectionChange;
            label = new Text(text);
            label.layoutSizeX = LayoutSize.WrapContent;
            label.layoutSizeY = LayoutSize.MatchParent;

            checkbox                = new Button(isRadioButton ? style.GetRadioButtonSprite() : style.GetCheckboxSprite());            
            checkbox.OnMouseClick   = () => { SetValue(!isSelected, true); };
            checkbox.MinSize = size;
            checkbox.layoutSizeX    = LayoutSize.WrapContent;
            checkbox.layoutSizeY    = LayoutSize.WrapContent;

            selectedSprite = new Image(isRadioButton ? style.GetRadioButtonSelectionSprite() : style.GetCheckboxSelectionSprite());
            selectedSprite.MinSize = size;


            SetValue(startValue, false);

            layoutSizeX = LayoutSize.WrapContent;
            layoutSizeY = LayoutSize.WrapContent;
            AddChild(selectedSprite);
            AddChild(label);
            AddChild(checkbox);
        }
   
        public Checkbox SetValue(bool value, bool makeCallback = false)
        {
            isSelected = value;

            if (isSelected)
                selectedSprite.Open();
            else
                selectedSprite.Close();

            if (makeCallback && OnSelectionChange != null)
                OnSelectionChange(isSelected);
            return this;
        }

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            checkbox.MinSize = new Point(32,32);
            base.SetSizeAndPosition(canvas, position, size);
            checkbox.SetSizeAndPosition(canvas, Padding, Point.Zero);
            selectedSprite.SetSizeAndPosition(canvas, Padding, checkbox.Size);
            label.SetSizeAndPosition(canvas, Padding + new Point(Margin + checkbox.Size.X, 0), checkbox.Size);


        }

        public override Point CalculateMinSize(Canvas canvas)
        {
            Point p1 = checkbox.CalculateMinSize(canvas);
            Point p2 = label.CalculateMinSize(canvas);
            MinSize = Padding + Padding + new Point(Margin, 0) + new Point(p1.X + p2.X, Math.Max(p1.Y, p2.Y));
            return MinSize;
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            if (sprite != null)
                sprite.Render(spriteBatch, new Rectangle(parentPos + Position, Size));

            if (Canvas.DRAW_DEBUG)
            {
                Color c = Color.Red;
                Vector2 p = parentPos.ToVector2() + Position.ToVector2();
                spriteBatch.DrawLine(p, p + new Vector2(Size.X, 0), c);
                spriteBatch.DrawLine(p + new Vector2(Size.X, 0), p + new Vector2(Size.X, Size.Y), c);
                spriteBatch.DrawLine(p + new Vector2(Size.X, Size.Y), p + new Vector2(0, Size.Y), c);
                spriteBatch.DrawLine(p + new Vector2(0, Size.Y), p + new Vector2(0, 0), c);
            }

            label.RenderAsChild(spriteBatch, parentPos + Position);
            checkbox.RenderAsChild(spriteBatch, parentPos + Position);
            selectedSprite.RenderAsChild(spriteBatch, parentPos + Position);
        }

    }
}
