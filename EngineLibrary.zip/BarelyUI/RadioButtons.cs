﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace BarelyUI
{
    public class RadioButtons : UIElement
    {
        int selected = -1;
        VerticalLayout layout;
        int elemCount;
        Action<int> OnSelection;
        Checkbox[] boxes;

        public RadioButtons(string[] captions, Action<int> OnSelection, string title = null, int startIndex = 0)
        {
            this.OnSelection = OnSelection;
            layoutSizeX = LayoutSize.WrapContent;
            layoutSizeY = LayoutSize.WrapContent;

            layout = new VerticalLayout();
            layout.layoutSizeX = LayoutSize.MatchParent;
            layout.layoutSizeY = LayoutSize.WrapContent;
            layout.Margin = 2;

            AddChild(layout);
            layout.Padding = new Point(2, 10);

            var style = Styles.Style.GetActiveStyle();

            if(title != null)
            {
                layout.AddChild(new Text(title, style.GetRadioButtonFont(), style.GetRadioButtonTextColor()));
            }

            elemCount = captions.Length;
            boxes = new Checkbox[elemCount];
            for (int i = 0; i < elemCount; i++)
            {
                int index = i;
                Checkbox cb = new Checkbox(captions[i], (b) => { if (b) SelectionChanged(index); else boxes[index].SetValue(true, false); }, true, false);
                cb.Padding = new Point(1, 1);
                boxes[i] = cb;
                layout.AddChild(cb);
            }
            SelectionChanged(startIndex);
            boxes[startIndex].SetValue(true, false);
        }

        protected void SelectionChanged(int newIndex)
        {
            if(selected > -1)
            {
                boxes[selected].SetValue(false, false);
            }
            if(selected != newIndex)
            {
                selected = newIndex;            
                OnSelection(newIndex);
            }
        }

        
        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            base.SetSizeAndPosition(canvas, position, size);
            this.Size = Padding + Padding + layout.Size;
        }
        

        public override Point CalculateMinSize(Canvas canvas)
        {
            MinSize = layout.CalculateMinSize(canvas);
            return MinSize;
        }

    }
   
}
