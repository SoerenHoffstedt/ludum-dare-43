﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Barely.Util;
using BarelyUI.Styles;
using System.Diagnostics;

namespace BarelyUI
{
    public class Window : Panel
    {
        Panel contentPanel;
        TitleBar titleBar;

        public bool draggable = true;

        public Window(Panel contentPanel, string title, Canvas canvas) : this(title, canvas)
        {
            this.contentPanel = contentPanel;                        
            childElements.Add(contentPanel);                        
        }

        public Window(string title, Canvas canvas)
        {            
            titleBar = new TitleBar(title, this, canvas);
            childElements.Add(titleBar);            
            autoAdjustPosSizeOfChilds = false;
            layoutSizeX = LayoutSize.FixedSize;
            layoutSizeY = LayoutSize.FixedSize;
            Padding = new Point(0, 0);
        }

        public Window SetIsDraggable(bool newValue)
        {
            draggable = newValue;
            return this;
        }

        public void SetContentPanel(Panel contentPanel)
        {          
            this.contentPanel = contentPanel;
            childElements.Add(contentPanel);
        }

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            Point tbMinSize = titleBar.CalculateMinSize(canvas);
            contentPanel.SetSizeAndPosition(canvas, Padding + new Point(0, tbMinSize.Y), size);

            titleBar.SetSizeAndPosition(canvas, Padding, contentPanel.Size + Padding + Padding);            
            Size = contentPanel.Size + Padding + Padding;
            Size += new Point(0, titleBar.Size.Y);
            base.SetSizeAndPosition(canvas, position, Size);
       }

        public override Point CalculateMinSize(Canvas canvas)
        {
            MinSize = Point.Zero;
            return MinSize;
        }

    }

    public class TitleBar : UIElement
    {
        Text titleText;
        Canvas canvas;
        Button closeButton;
        Window parent;

        public TitleBar(string title, Window parent, Canvas canvas)
        {
            this.parent = parent;
            this.canvas = canvas;
            Padding = new Point(6, 6);
            layoutSizeX = LayoutSize.MatchParent;
            layoutSizeY = LayoutSize.WrapContent;
            //TODO: Adjust to titlebar font and color
            var style = Style.GetActiveStyle();
            titleText = new Text(title, style.GetTitlebarFont(), style.GetTitlebarTextColor());            
            closeButton = new Button(style.GetTitlebarCloseSprite());
            closeButton.OnMouseClick = () => parent.Close();
            sprite = style.GetTitlebarSprite();
            AddChild(titleText);
            AddChild(closeButton);
        }

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            base.SetSizeAndPosition(canvas, position, size);
            closeButton.Position = new Point(Size.X - Padding.X - closeButton.Size.X, Padding.Y);
        }

        public override Point CalculateMinSize(Canvas canvas)
        {
            Point bMin = closeButton.CalculateMinSize(canvas);
            Point tMin = titleText.CalculateMinSize(canvas);
            MinSize = Padding + Padding + new Point(bMin.X + tMin.X + 10, Math.Max(bMin.Y, tMin.Y));
            return MinSize;
        }

        public override void LeftMouseStillPressed(Point localMousePos)
        {
            if (parent.draggable)
            {
                Debug.WriteLine(parent.draggable);
                Point Resolution = canvas.Resolution;
                Point newPos = parent.Position + Input.GetMousePositionDelta();
                if (newPos.X < 0)
                    newPos.X = 0;
                if (newPos.Y < 0)
                    newPos.Y = 0;
                if (newPos.X > Resolution.X - 100)
                    newPos.X = Resolution.X - 100;
                if (newPos.Y > Resolution.Y - 100)
                    newPos.Y = Resolution.Y - 100;
                parent.Position = newPos;
            }
        }
    }

}
