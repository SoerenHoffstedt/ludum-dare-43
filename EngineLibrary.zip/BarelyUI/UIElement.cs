﻿using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarelyUI
{
    public abstract class UIElement
    {
        protected Canvas canvas;
        internal UIElement parent;

        internal virtual void SetParentAndCanvas(Canvas canvas, UIElement parent)
        {
            this.canvas = canvas;
            this.parent = parent;
            foreach(UIElement child in childElements)
            {
                child.SetParentAndCanvas(canvas, this);
            }
        }

        protected bool finished = false;
        protected bool ignoreScrollOffset = false;
        internal Point scrollOffset;

        protected bool hasMouseDownFocus;

        public Sprite sprite;

        public Point Position { get; set; }

        public int X { get { return Position.X; } set { ChangeXPosition(value); } }

        public int Y { get { return Position.Y; } set { ChangeYPosition(value); } }        

        public Point Size            { get; set; }
        public Point MinSize         { get; set; }
        public Point WrappingMinSize { get; set; }

        public LayoutSize layoutSizeX   = LayoutSize.WrapContent;
        public LayoutSize layoutSizeY    = LayoutSize.WrapContent;

        protected bool autoAdjustPosSizeOfChilds = true;

        /// <summary>
        /// size of the space at the borders of the UIElement that 
        /// </summary>
        public Point Padding    { get; set; }

        public bool isOpen = true;

        public bool isMouseOver = false;

        public bool isMouseDown = false;

        public bool Interactable { get; set; } = true;

        public Color color = Color.White;

        protected List<UIElement> childElements = new List<UIElement>();

        /// <summary>
        /// if SetSizeAndPosition is automatically called upon creation or the users responsibility
        /// </summary>
        public bool setPositionOnAdd = false;

        public string tooltipID;

        public Action OnMouseClick;

        public Action OnMouseEnter;

        public Action OnMouseExit;

        public virtual void Update(float deltaTime)
        {
            if (isOpen)
            {
                foreach (UIElement child in childElements)
                    child.Update(deltaTime);
            }
        }

        public void Render(SpriteBatch spriteBatch)
        {
            this.RenderAsChild(spriteBatch, Point.Zero);
        }

        public virtual void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            if (!isOpen)
                return;

            if (sprite != null)
                sprite.Render(spriteBatch, new Rectangle(Position + parentPos + scrollOffset, Size), color);

            
            Color c = Color.Red;
            if (this is TitleBar)
                c = Color.Blue;

            if (Canvas.DRAW_DEBUG)
            {
                Vector2 p = parentPos.ToVector2() + Position.ToVector2();
                spriteBatch.DrawLine(p, p + new Vector2(Size.X, 0), c);
                spriteBatch.DrawLine(p + new Vector2(Size.X, 0), p + new Vector2(Size.X, Size.Y), c);
                spriteBatch.DrawLine(p + new Vector2(Size.X, Size.Y), p + new Vector2(0, Size.Y), c);
                spriteBatch.DrawLine(p + new Vector2(0, Size.Y), p + new Vector2(0, 0), c);
            }
            

            foreach (UIElement child in childElements)
            {
                child.RenderAsChild(spriteBatch, parentPos + Position + scrollOffset);
            }
        }

        public void AddChild(UIElement element)
        {
            childElements.Add(element);
            if (setPositionOnAdd)
            {
                //TODO
            }                
        }

        public void AddChild(params UIElement[] elements)
        {
            foreach(UIElement element in elements)
            {
                childElements.Add(element);
                if (setPositionOnAdd)
                {
                    //TODO
                }
            }
        }

        internal void ChangeXPosition(int x)
        {
            Position = new Point(x, Position.Y);
        }

        internal void ChangeYPosition(int y)
        {
            Position = new Point(Position.X, y);
        }

        public virtual void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            if(this is Text)
            {
                Text t = (Text)this;                
                int k = 10;
            }
            CalculateMinSize(canvas);
            Position = position;
            
            switch (layoutSizeX)
            {
                case LayoutSize.MatchParent:                    
                    break;
                case LayoutSize.WrapContent:
                    size.X = MinSize.X;
                    break;
                case LayoutSize.FixedSize:
                    size.X = Size.X;
                    break;
            }

            switch (layoutSizeY)
            {
                case LayoutSize.MatchParent:                    
                    break;
                case LayoutSize.WrapContent:
                    size.Y = MinSize.Y;
                    break;
                case LayoutSize.FixedSize:
                    size.Y = Size.Y;
                    break;
            }

            Size = size;

            if(autoAdjustPosSizeOfChilds)
            {
                foreach(UIElement child in childElements)
                {
                    child.SetSizeAndPosition(canvas, Padding, Size - Padding - Padding);
                }
            }

        }

        public abstract Point CalculateMinSize(Canvas canvas);

        public UIElement SetFixedWidth(int width)
        {
            Size = new Point(width, Size.Y);
            layoutSizeX = LayoutSize.FixedSize;
            return this;
        }

        public UIElement SetFixedHeight(int height)
        {
            Size = new Point(Size.Y, height);
            layoutSizeY = LayoutSize.FixedSize;
            return this;
        }

        public UIElement SetFixedSize(int width, int height)
        {
            return SetFixedSize(new Point(width, height));
        }

        public UIElement SetFixedSize(Point s)
        {
            Size = s;
            layoutSizeX = LayoutSize.FixedSize;
            layoutSizeY = LayoutSize.FixedSize;
            return this;
        }

        public UIElement SetLayoutSize(LayoutSize x, LayoutSize y)
        {
            layoutSizeX = x;
            layoutSizeY = y;
            return this;
        }

        public UIElement SetLayoutSizeForBoth(LayoutSize both)
        {
            layoutSizeX = both;
            layoutSizeY = both;
            return this;
        }


        public virtual void Open()
        {
            isOpen = true;
        }

        public virtual void Close()
        {
            isOpen = false;
        }

        #region Interactions

        public UIElement FindMouseOverElement(ref Point localMousePos)
        {
            if (childElements == null || childElements.Count == 0)
                return this;

            var toReturn = this;
            localMousePos -= Position;
            localMousePos -= scrollOffset;

            foreach (UIElement element in childElements)
            {
                if (!element.isOpen)
                    continue;
                if (element.ignoreScrollOffset)
                    localMousePos += scrollOffset;

                if(new Rectangle(element.Position, element.Size).Contains(localMousePos))
                {
                    if (element.Interactable)
                        toReturn = element.FindMouseOverElement(ref localMousePos);                    
                } else if (element.isMouseOver)
                {
                    element.MouseExit();
                }

                if (element.ignoreScrollOffset)
                    localMousePos -= scrollOffset;

            }

            return toReturn;
        }        

        public virtual void MouseEnter()
        {
            isMouseOver = true;
            if (OnMouseEnter != null)
                OnMouseEnter();
        }

        public virtual void MouseExit()
        {
            isMouseOver = false;
            if (OnMouseExit != null)
                OnMouseExit();
        }

        public virtual void MouseStillOver()
        {

        }

        public virtual void LeftMouseClick(Point localMousePos)
        {
            isMouseDown = false;            
            if (OnMouseClick != null)
            {
                OnMouseClick();
                Sounds.Play("click");
            }
        }

        public virtual void LeftMouseDown(Point localMousePos)
        {
            isMouseDown = true;
        }

        public virtual void LeftMouseStillPressed(Point localMousePos)
        {

        }

        public virtual void RightMouseClick(Point localMousePos)
        {

        }

        public virtual void RightMouseDown(Point localMousePos)
        {

        }

        public virtual void RightMouseStillPressed(Point localMousePos)
        {

        }

        public virtual void MiddleMouseClick(Point localMousePos)
        {

        }

        public virtual void MiddleMouseDown(Point localMousePos)
        {

        }

        public virtual void MiddleMouseStillPressed(Point localMousePos)
        {

        }

        public virtual void ScrollWheelDown(int delta)
        {

        }

        public virtual void ScrollWheelUp(int delta)
        {

        }

        public virtual void LooseMouseDownFocus()
        {
            
        }

        #endregion


    }

    public enum LayoutSize
    {
        MatchParent,
        WrapContent,
        FixedSize
    }

    public enum AnchorX
    {
        Left,
        Middle,
        Right
    }

    public enum AnchorY
    {
        Top,
        Middle,
        Bottom
    }
}
