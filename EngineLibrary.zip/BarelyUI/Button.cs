﻿using Barely.Util;
using BarelyUI.Layouts;
using BarelyUI.Styles;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarelyUI
{
    public class Button : UIElement
    {
        private Color[] colors;
        private Text caption;
        private ButtonType type;
        
        public Button(string caption, Point minSize) : this(caption)
        {
            MinSize = minSize;
        }

        public Button(string caption)
        {
            type        = ButtonType.Text;

            var style   = Style.GetActiveStyle();
            sprite      = style.GetButtonSprite();
            colors      = style.GetButtonColors();

            var layout  = Layout.GetActiveLayout();
            Padding     = layout.GetButtonPadding();
            layoutSizeX = layout.GetButtonLayoutSizeX();
            layoutSizeY = layout.GetButtonLayoutSizeY();

            this.caption = new Text(caption, style.GetButtonFont(), style.GetButtonTextColor());
            this.caption.Interactable = false;
            this.caption.layoutSizeX = LayoutSize.MatchParent;
            this.caption.layoutSizeY = LayoutSize.MatchParent;
            this.caption.allignmentX = Allignment.Middle;
            AddChild(this.caption);
        }

        public Button(Sprite sprite)
        {
            this.sprite = sprite;
            Size = MinSize = sprite.spriteRect.Size;
            layoutSizeX = LayoutSize.FixedSize;
            layoutSizeY = LayoutSize.FixedSize;
            type = ButtonType.Image;
            colors = Style.GetActiveStyle().GetButtonColors();
        }

        public Button(Sprite sprite, Point minSize)
        {
            this.sprite = sprite;
            Size = MinSize = minSize;
            layoutSizeX = LayoutSize.FixedSize;
            layoutSizeY = LayoutSize.FixedSize;
            type = ButtonType.Image;
            colors = Style.GetActiveStyle().GetButtonColors();
        }
    
        public override Point CalculateMinSize(Canvas canvas)
        {
            if(type == ButtonType.Text)
                MinSize = Padding * new Point(2, 2) + caption.CalculateMinSize(canvas);

            return MinSize;
        }

        public override void MouseEnter()
        {
            if (!isMouseOver && !isMouseDown)
            {
                Sounds.Play("buttonEnter");
            }
            base.MouseEnter();
            color = colors[(int)ButtonColors.MouseOver];            
        }

        public override void MouseExit()
        {
            base.MouseExit();
            color = colors[(int)ButtonColors.Normal];
        }        

        public void ChangeText(string newTextId)
        {
            System.Diagnostics.Debug.Assert(type == ButtonType.Text);
            caption.SetText(newTextId);
        }

        public void ChangeColor(ButtonColors state)
        {
            color = colors[(int)state];
        }

        enum ButtonType
        {
            Image,
            Text
        }

        public enum ButtonColors
        {
            Normal      = 0,
            MouseOver   = 1,
            MouseDown   = 2,
            Inactive    = 3
        }

    }
}
