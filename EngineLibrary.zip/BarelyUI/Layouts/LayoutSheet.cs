﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarelyUI.Layouts
{

    /// <summary>
    /// Steps to add new parameters: 
    ///     - Add the data fields, as Nullable if struct. 
    ///     - Add getter method that returns the data field if not null and else retruns value of parent layout.
    ///     - Add Parsing to LoadFromXml.
    ///     - Use the parameters in the relevant UIElement.
    /// </summary>
    public class LayoutSheet
    {
        #region data fields

        internal string id;

        public LayoutSheet CurrentParentLayout { get; internal set; }

        // Panel
        private Point?          panelPadding;
        private int?            panelMargin;
        private AnchorX?        panelAnchorX;
        private AnchorY?        panelAnchorY;
        private LayoutSize?     panelLayoutSizeX;
        private LayoutSize?     panelLayoutSizeY;
        private LayoutOverflow? panelLayoutOverflow;
        private LayoutFill?     panelLayoutFill;
        private bool?           panelHasChildLayoutOverwrite;
        private LayoutSize?     panelChildLayoutOverwrite;
        private AnchorX?        panelChildAllignX;
        private AnchorY?        panelChildAllignY;

        //TODO: Window

        // Button
        private Point?          buttonPadding;
        private LayoutSize?     buttonLayoutSizeX;
        private LayoutSize?     buttonLayoutSizeY;

        // Key Value Text
        private Point?          keyValueTextPadding;
        private LayoutSize?     keyValueTextLayoutSizeX;
        private LayoutSize?     keyValueTextLayoutSizeY;
        private float?          keyValueTextSizeSplitKey;
        private float?          keyValueTextSizeSplitValue;

        // Text Field
        private Point?          textPadding;
        private LayoutSize?     textLayoutSizeX;
        private LayoutSize?     textLayoutSizeY;
        private Allignment?     textAllignmentX;
        private Allignment?     textAllignmentY;

        #endregion

        #region Getter

        // Text Field
        public Point GetTextPadding()
        {
            return textPadding != null ? textPadding.Value : CurrentParentLayout.GetTextPadding();
        }

        public LayoutSize GetTextLayoutSizeX()
        {
            return textLayoutSizeX != null ? textLayoutSizeX.Value : CurrentParentLayout.GetTextLayoutSizeX();
        }

        public LayoutSize GetTextLayoutSizeY()
        {
            return textLayoutSizeY != null ? textLayoutSizeY.Value : CurrentParentLayout.GetTextLayoutSizeY();
        }

        public Allignment GetTextAllignmentX()
        {
            return textAllignmentX != null ? textAllignmentX.Value : CurrentParentLayout.GetTextAllignmentX();
        }

        public Allignment GetTextAllignmentY()
        {
            return textAllignmentY != null ? textAllignmentY.Value : CurrentParentLayout.GetTextAllignmentY();
        }

        // Key Value Text
        public Point GetKeyValueTextPadding()
        {
            return keyValueTextPadding != null ? keyValueTextPadding.Value : CurrentParentLayout.GetKeyValueTextPadding();
        }

        public LayoutSize GetKeyValueTextLayoutSizeX()
        {
            return keyValueTextLayoutSizeX != null ? keyValueTextLayoutSizeX.Value : CurrentParentLayout.GetKeyValueTextLayoutSizeX();
        }

        public LayoutSize GetKeyValueTextLayoutSizeY()
        {
            return keyValueTextLayoutSizeY != null ? keyValueTextLayoutSizeY.Value : CurrentParentLayout.GetKeyValueTextLayoutSizeY();
        }

        public float GetKeyValueTextSizeSplitKey()
        {
            return keyValueTextSizeSplitKey != null ? keyValueTextSizeSplitKey.Value : CurrentParentLayout.GetKeyValueTextSizeSplitKey();
        }

        public float GetKeyValueTextSizeSplitValue()
        {
            return keyValueTextSizeSplitValue != null ? keyValueTextSizeSplitValue.Value : CurrentParentLayout.GetKeyValueTextSizeSplitValue();
        }

        // Button
        public Point GetButtonPadding()
        {
            return buttonPadding != null ? buttonPadding.Value : CurrentParentLayout.GetButtonPadding();
        }

        public LayoutSize GetButtonLayoutSizeX()
        {
            return buttonLayoutSizeX != null ? buttonLayoutSizeX.Value : CurrentParentLayout.GetButtonLayoutSizeX();
        }

        public LayoutSize GetButtonLayoutSizeY()
        {
            return buttonLayoutSizeY != null ? buttonLayoutSizeY.Value : CurrentParentLayout.GetButtonLayoutSizeY();
        }

        // Panel
        public Point GetPanelPadding()
        {
            return panelPadding != null ? panelPadding.Value : CurrentParentLayout.GetPanelPadding();
        }

        public int GetPanelMargin()
        {
            return panelMargin != null ? panelMargin.Value : CurrentParentLayout.GetPanelMargin();
        }

        public AnchorX GetPanelAnchorX()
        {
            return panelAnchorX != null ? panelAnchorX.Value : CurrentParentLayout.GetPanelAnchorX();
        }

        public AnchorY GetPanelAnchorY()
        {
            return panelAnchorY != null ? panelAnchorY.Value : CurrentParentLayout.GetPanelAnchorY();
        }

        public LayoutSize GetPanelLayoutSizeX()
        {
            return panelLayoutSizeX != null ? panelLayoutSizeX.Value : CurrentParentLayout.GetPanelLayoutSizeX();
        }

        public LayoutSize GetPanelLayoutSizeY()
        {
            return panelLayoutSizeY != null ? panelLayoutSizeY.Value : CurrentParentLayout.GetPanelLayoutSizeY();
        }

        public LayoutOverflow GetPanelLayoutOverflow()
        {
            return panelLayoutOverflow != null ? panelLayoutOverflow.Value : CurrentParentLayout.GetPanelLayoutOverflow();
        }

        public LayoutFill GetPanelLayoutFill()
        {
            return panelLayoutFill != null ? panelLayoutFill.Value : CurrentParentLayout.GetPanelLayoutFill();
        }

        public bool GetPanelHasChildLayoutOverwrite()
        {
            return panelHasChildLayoutOverwrite != null ? panelHasChildLayoutOverwrite.Value : CurrentParentLayout.GetPanelHasChildLayoutOverwrite();
        }

        public LayoutSize GetPanelChildLayoutOverwrite()
        {
            return panelChildLayoutOverwrite != null ? panelChildLayoutOverwrite.Value : CurrentParentLayout.GetPanelChildLayoutOverwrite();
        }

        public AnchorX GetPanelChildAllignX()
        {
            return panelChildAllignX != null ? panelChildAllignX.Value : CurrentParentLayout.GetPanelChildAllignX();
        }

        public AnchorY GetPanelChildAllignY()
        {
            return panelChildAllignY != null ? panelChildAllignY.Value : CurrentParentLayout.GetPanelChildAllignY();
        }

        #endregion


        public static LayoutSheet LoadFromXml(System.Xml.XmlNode n, string name)
        {
            LayoutSheet ls = new LayoutSheet();
            ls.id = name;

            var panelNode = n.SelectSingleNode("panel");
            if(panelNode != null)
                LoadPanelFields(panelNode, ls);

            var buttonNode = n.SelectSingleNode("button");
            if (buttonNode != null)
                LoadButtonFields(buttonNode, ls);

            var keyValueNode = n.SelectSingleNode("keyValueText");
            if (keyValueNode != null)
                LoadKeyValueTextFields(keyValueNode, ls);

            var textNode = n.SelectSingleNode("text");
            if (textNode != null)
                LoadTextFields(textNode, ls);

            return ls;
        }        

        private static void LoadTextFields(System.Xml.XmlNode n, LayoutSheet ls)
        {
            {
                var paddingNode = n.SelectSingleNode("padding");
                if (paddingNode != null)
                    ls.textPadding = new Point(int.Parse(paddingNode.Attributes["x"].Value), int.Parse(paddingNode.Attributes["y"].Value));
            }
            {
                var layoutSizeNode = n.SelectSingleNode("layoutSize");
                if (layoutSizeNode != null)
                {
                    ls.textLayoutSizeX = (LayoutSize)Enum.Parse(typeof(LayoutSize), layoutSizeNode.Attributes["x"].Value);
                    ls.textLayoutSizeY = (LayoutSize)Enum.Parse(typeof(LayoutSize), layoutSizeNode.Attributes["y"].Value);
                }
            }
            {
                var allignmentNode = n.SelectSingleNode("allignment");
                if (allignmentNode != null)
                {
                    ls.textAllignmentX = (Allignment)Enum.Parse(typeof(Allignment), allignmentNode.Attributes["x"].Value);
                    ls.textAllignmentY = (Allignment)Enum.Parse(typeof(Allignment), allignmentNode.Attributes["y"].Value);
                }
            }
        }

        private static void LoadKeyValueTextFields(System.Xml.XmlNode n, LayoutSheet ls)
        {
            var paddingNode = n.SelectSingleNode("padding");
            if (paddingNode != null)
                ls.keyValueTextPadding = new Point(int.Parse(paddingNode.Attributes["x"].Value), int.Parse(paddingNode.Attributes["y"].Value));

            var layoutSizeNode = n.SelectSingleNode("layoutSize");
            if (layoutSizeNode != null)
            {
                ls.keyValueTextLayoutSizeX = (LayoutSize)Enum.Parse(typeof(LayoutSize), layoutSizeNode.Attributes["x"].Value);
                ls.keyValueTextLayoutSizeY = (LayoutSize)Enum.Parse(typeof(LayoutSize), layoutSizeNode.Attributes["y"].Value);
            }

            var splitNode = n.SelectSingleNode("sizeSplit");
            if(splitNode != null)
            {
                 ls.keyValueTextSizeSplitKey     = float.Parse(splitNode.Attributes["key"].Value, System.Globalization.CultureInfo.InvariantCulture);
                 ls.keyValueTextSizeSplitValue   = float.Parse(splitNode.Attributes["value"].Value, System.Globalization.CultureInfo.InvariantCulture);
            }
        }

        private static void LoadButtonFields(System.Xml.XmlNode n, LayoutSheet ls)
        {
            var paddingNode = n.SelectSingleNode("padding");
            if (paddingNode != null)
                ls.buttonPadding = new Point(int.Parse(paddingNode.Attributes["x"].Value), int.Parse(paddingNode.Attributes["y"].Value));

            var layoutSizeNode = n.SelectSingleNode("layoutSize");
            if (layoutSizeNode != null)
            {
                ls.buttonLayoutSizeX = (LayoutSize)Enum.Parse(typeof(LayoutSize), layoutSizeNode.Attributes["x"].Value);
                ls.buttonLayoutSizeY = (LayoutSize)Enum.Parse(typeof(LayoutSize), layoutSizeNode.Attributes["y"].Value);
            }
        }

        private static void LoadPanelFields(System.Xml.XmlNode n, LayoutSheet ls)
        {
            var panelPadding = n.SelectSingleNode("padding");
            if (panelPadding != null)
                ls.panelPadding = new Point(int.Parse(panelPadding.Attributes["x"].Value), int.Parse(panelPadding.Attributes["y"].Value));

            var panelMargin = n.SelectSingleNode("margin");
            if (panelMargin != null)
                ls.panelMargin = int.Parse(panelMargin.Attributes["val"].Value);


            var layoutSize = n.SelectSingleNode("layoutSize");
            if(layoutSize != null)
            {
                ls.panelLayoutSizeX = (LayoutSize)Enum.Parse(typeof(LayoutSize), layoutSize.Attributes["x"].Value);
                ls.panelLayoutSizeY = (LayoutSize)Enum.Parse(typeof(LayoutSize), layoutSize.Attributes["y"].Value);
            }

            var panelAnchor = n.SelectSingleNode("anchor");
            if (panelAnchor != null)
            {
                ls.panelAnchorX = (AnchorX)Enum.Parse(typeof(AnchorX), panelAnchor.Attributes["x"].Value);
                ls.panelAnchorY = (AnchorY)Enum.Parse(typeof(AnchorY), panelAnchor.Attributes["y"].Value);
            }

            var panelOverflow = n.SelectSingleNode("layoutOverflow");
            if (panelOverflow != null)
                ls.panelLayoutOverflow = (LayoutOverflow)Enum.Parse(typeof(LayoutOverflow), panelOverflow.Attributes["val"].Value);

            var panelFill = n.SelectSingleNode("layoutFill");
            if (panelFill != null)
                ls.panelLayoutFill = (LayoutFill)Enum.Parse(typeof(LayoutFill), panelFill.Attributes["val"].Value);

            var panelHasChildOverwrite = n.SelectSingleNode("hasChildLayoutOverwrite");
            if(panelHasChildOverwrite != null)
            {
                ls.panelHasChildLayoutOverwrite = bool.Parse(panelHasChildOverwrite.Attributes["val"].Value);
            }

            var panelChildOverwrite = n.SelectSingleNode("childLayoutOverwrite");
            if (panelChildOverwrite != null)
            {                
                ls.panelChildLayoutOverwrite = (LayoutSize)Enum.Parse(typeof(LayoutSize), panelChildOverwrite.Attributes["val"].Value);
            }

            var panelChildAllign = n.SelectSingleNode("childAllign");
            if(panelChildAllign != null)
            {
                ls.panelChildAllignX = (AnchorX)Enum.Parse(typeof(AnchorX), panelChildAllign.Attributes["x"].Value);
                ls.panelChildAllignY = (AnchorY)Enum.Parse(typeof(AnchorY), panelChildAllign.Attributes["y"].Value);
            }

        }
    }
}
