﻿using Microsoft.Xna.Framework.Content;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BarelyUI.Layouts
{
    public static class Layout
    {

        private static Dictionary<string, LayoutSheet>  allLayouts;
        private static Stack<LayoutSheet>               activeLayouts;

        public static void InitializeLayouts(string file)
        {
            XmlDocument layoutDef = new XmlDocument();
            layoutDef.Load(file);

            allLayouts      = new Dictionary<string, LayoutSheet>();
            activeLayouts   = new Stack<LayoutSheet>();

            LoadLayouts(layoutDef);
        }

        public static void PushLayout(string layoutId)
        {
            Debug.Assert(activeLayouts.Count > 0);
            LayoutSheet newLayout = allLayouts[layoutId];
            newLayout.CurrentParentLayout = activeLayouts.Peek();
            activeLayouts.Push(newLayout);
        }

        /// <summary></summary>
        /// <param name="expectedName">the name you expect to pop. If name is different from active layout, exception will be thrown. Can be null to not check.</param>
        public static void PopLayout(string expectedName = null)
        {
            Debug.Assert(activeLayouts.Count > 0);
            
            if (activeLayouts.Count == 1)
            {
                throw new LayoutException("You can not pop the standard layout and currently no other layout is activated.");
            }
            LayoutSheet old = activeLayouts.Pop();            
            if(expectedName != null && old.id != expectedName)
            {
                throw new LayoutException("The active layout does not have the expected name. Push, Pop order might be confused.");
            }
            old.CurrentParentLayout = null;       
            Debug.Assert(activeLayouts.Count > 0);
        }

        public static LayoutSheet GetActiveLayout()
        {
            return activeLayouts.Peek();
        }


        private static void LoadLayouts(XmlDocument def)
        {
            string stdName = "standard";
            LayoutSheet stdLayout = LayoutSheet.LoadFromXml(def.SelectSingleNode("layouts/standard"), stdName);
            allLayouts.Add(stdName, stdLayout);
            activeLayouts.Push(stdLayout);

            foreach (XmlNode n in def.SelectNodes("layouts/layout"))
            {
                string name = n.Attributes["id"].Value;
                allLayouts.Add(name, LayoutSheet.LoadFromXml(n, name));
            }
        }

    }
}
